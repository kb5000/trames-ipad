// SPDX-License-Identifier: GPL-3.0-or-later
use super::tests::{admitted_process, kernel, progress_page};
use super::*;
use crate::execution_control::{Control, End};
use trames_execution::Registers;
use trames_memory::Permissions;

fn executable(p: &mut Process<trames_cpu::Cpu>, words: &[u32]) {
    for (i, word) in words.iter().enumerate() {
        p.memory
            .write_array(0x4000 + i as u64 * 4, word.to_le_bytes())
            .unwrap();
    }
    p.memory.protect(0x4000, 4096, Permissions::RX).unwrap();
}

#[test]
fn closing_is_one_way_even_when_legacy_handoff_races_completion() {
    for reason in [
        End::Budget,
        End::Cancelled,
        End::Exited,
        End::Failed,
        End::Deadlocked,
    ] {
        let control = Arc::new(Control::new(10));
        control.close(reason);
        std::thread::scope(|scope| {
            for _ in 0..8 {
                let control = &control;
                scope.spawn(move || control.handoff());
            }
        });
        assert_eq!(control.end(), Some(reason));
        assert!(control.claim().is_none());
    }
}

#[test]
fn a_genuine_futex_deadlock_still_reports_its_original_terminal_cause() {
    let mut k = kernel();
    let mut p = admitted_process(&k);
    executable(&mut p, &[0xd4000001, 0x14000000]);
    for (register, value) in [(0, 0x3000), (1, 128), (2, 0), (3, 0), (8, 98)] {
        p.cpu.set_x(register, value);
    }
    k.publish_task(1, &p);
    k.processes.insert(1, p);
    assert!(matches!(
        k.drive(&mut trames_linux::CapturedOutput::default(), 100000),
        Err(RuntimeError::Deadlock)
    ));
    assert!(k.source_completed);
}

#[test]
fn an_already_exited_root_uses_source_completion_without_a_host_retry_loop() {
    let mut k = kernel();
    let p = admitted_process(&k);
    k.publish_task(1, &p);
    k.processes.insert(1, p);
    let mut root = k.processes.checkout(&1).unwrap();
    k.exit(1, &mut root, 7 << 8);
    k.processes.insert(1, root);
    assert_eq!(
        k.drive(&mut trames_linux::CapturedOutput::default(), 100000)
            .unwrap()
            .code,
        7
    );
    assert!(k.source_completed);
    assert_eq!(k.service_requests, 0);
    assert!(k.cohort_return_syscalls.is_empty());
}

#[test]
fn single_cpu_root_exit_is_completed_by_the_source_lifecycle() {
    for cpus in [1, 4, 12] {
        let mut k = kernel();
        k.cpu_count = cpus;
        k.per_cpu.resize(cpus, Duration::ZERO);
        k.profile_syscalls = true;
        let mut root = admitted_process(&k);
        executable(&mut root, &[0xd28000e0, 0xd2800ba8, 0xd4000001]);
        k.publish_task(1, &root);
        k.processes.insert(1, root);
        let exit = k
            .drive(&mut trames_linux::CapturedOutput::default(), 100000)
            .unwrap();
        assert_eq!(exit.code, 7);
        assert_eq!(k.parallel_rounds, 1);
        assert!(k.worker_slices > 0);
        assert!(k.cohort_return_syscalls.is_empty());
        assert_eq!(k.serviced_syscalls, 0);
        assert!(k.processes.read(&1).family.status().is_some());
    }
}

#[test]
fn an_unclassified_cpu_yield_requeues_the_original_job_without_host_dispatch() {
    for cpus in [1, 4, 12] {
        let mut k = kernel();
        k.cpu_count = cpus;
        k.per_cpu.resize(cpus, Duration::ZERO);
        let mut p = admitted_process(&k);
        executable(&mut p, &[0xd28000e0, 0xd2800ba8, 0xd4000001]);
        p.pending_cpu = Some(SliceOutcome::Yield { instructions: 0 });
        k.publish_task(1, &p);
        k.processes.insert(1, p);
        assert_eq!(
            k.drive(&mut trames_linux::CapturedOutput::default(), 10000)
                .unwrap()
                .code,
            7
        );
        assert_eq!(k.parallel_rounds, 1);
        assert!(k.cohort_return_syscalls.is_empty());
        assert_eq!(k.service_requests, 0);
    }
}

#[test]
fn a_legacy_proc_ofd_uses_its_original_full_linux_body_without_a_host_join() {
    struct Unavailable;
    impl trames_vfs::ProcSource for Unavailable {
        fn available(&self, _: trames_vfs::ProcRefresh) -> bool {
            false
        }
        fn observe(&self, _: trames_vfs::ProcQuery<'_>) -> trames_vfs::RuntimeInfo {
            panic!("the unavailable query fast path was invoked")
        }
    }
    for cpus in [1, 4, 12] {
        let mut k = kernel();
        k.cpu_count = cpus;
        k.per_cpu.resize(cpus, Duration::ZERO);
        k.profile_syscalls = true;
        let mut p = admitted_process(&k);
        p.linux.vfs.set_runtime_info(1, Default::default());
        p.linux.vfs.set_proc_source(Arc::new(Unavailable));
        let fd = p.linux.vfs.open_at(-100, b"/proc/version", 0, 0).unwrap();
        let expected = p.linux.vfs.pread(fd, 8, 0).unwrap();
        assert_eq!(expected.len(), 8);
        executable(
            &mut p,
            &[
                0xd4000001, 0xd2840009, 0xf9000120, 0xd28000e0, 0xd2800ba8, 0xd4000001,
            ],
        );
        for (i, value) in [fd as u64, 0x1800, 8, 0, 0, 0].into_iter().enumerate() {
            p.cpu.set_x(i, value);
        }
        p.cpu.set_x(8, 63);
        k.publish_task(1, &p);
        k.processes.insert(1, p);
        assert_eq!(
            k.drive(&mut trames_linux::CapturedOutput::default(), 100000)
                .unwrap()
                .code,
            7
        );
        let p = k.processes.read(&1);
        assert_eq!(p.memory.read_u64(0x2000).unwrap(), 8);
        assert_eq!(
            p.memory.read_array::<8>(0x1800).unwrap().as_slice(),
            expected
        );
        assert_eq!(k.parallel_rounds, 1);
        assert!(k.cohort_return_syscalls.is_empty());
        assert_eq!(k.service_requests, 0);
    }
}

#[test]
fn shared_host_statistics_and_an_accepted_peer_stay_on_their_original_executors() {
    struct Output {
        console: Arc<dyn trames_vfs::ConsoleIo>,
        samples: Arc<std::sync::Mutex<Vec<std::thread::ThreadId>>>,
    }
    impl GuestOutput for Output {
        fn source_console(&mut self) -> Arc<dyn trames_vfs::ConsoleIo> {
            self.console.clone()
        }
        fn host_memory_source(
            &self,
        ) -> Option<Arc<dyn Fn() -> trames_linux::HostMemoryInfo + Send + Sync>> {
            let samples = self.samples.clone();
            Some(Arc::new(move || {
                samples.lock().unwrap().push(std::thread::current().id());
                trames_linux::HostMemoryInfo {
                    total: 1 << 30,
                    free: 1 << 29,
                    available: 1 << 29,
                }
            }))
        }
        fn write(&mut self, _: trames_linux::OutputFd, _: &[u8]) -> std::io::Result<usize> {
            panic!("console bytes must use their original source provider")
        }
    }
    for cpus in [1, 4, 12] {
        let host_thread = std::thread::current().id();
        let writes = Arc::new(std::sync::Mutex::new(Vec::new()));
        let recorded = writes.clone();
        let console = Arc::new(trames_vfs::ConsoleCallbacks::new(
            |_| Ok(Vec::new()),
            move |_, bytes| {
                recorded
                    .lock()
                    .unwrap()
                    .push((std::thread::current().id(), bytes.to_vec()));
                Ok(bytes.len())
            },
            |_, events| (events, [0; 2]),
        ));
        let mut output = Output {
            console,
            samples: Arc::default(),
        };
        let mut k = kernel();
        k.cpu_count = cpus;
        k.per_cpu.resize(cpus, Duration::ZERO);
        k.workers = crate::workers::Pool::new(1);
        k.memory_limits = crate::MemoryLimits::host_managed();
        let mut root = admitted_process(&k);
        root.signals.io.scheduling.set_affinity(1);
        executable(
            &mut root,
            &[
                0xd4000001, 0xd2860009, 0xb940012a, 0x34ffffea, 0xd28000e0, 0xd2800ba8, 0xd4000001,
            ],
        );
        root.memory.write(0x1800, b"peer").unwrap();
        root.memory.protect(0x5000, 4096, Permissions::RW).unwrap();
        for (i, word) in [
            0xd4000001u32,
            0xd2860009,
            0xd280002a,
            0xb900012a,
            0x14000000,
        ]
        .into_iter()
        .enumerate()
        {
            root.memory
                .write_array(0x5000 + i as u64 * 4, word.to_le_bytes())
                .unwrap();
        }
        root.memory.protect(0x5000, 4096, Permissions::RX).unwrap();
        root.cpu.set_x(0, 0x1000);
        root.cpu.set_x(8, 179);
        let memory = root.memory.share();
        let mut peer = root.fork_with_memory(memory);
        peer.tgid = 2;
        peer.cpu.set_pc(0x5004);
        for (i, value) in [1, 0x1800, 4, 0, 0, 0].into_iter().enumerate() {
            peer.cpu.set_x(i, value);
        }
        peer.cpu.set_x(8, 64);
        peer.pending_cpu = Some(SliceOutcome::Syscall { instructions: 0 });
        peer.seccomp_entry = Some(
            peer.seccomp
                .entry_decision(64, 0x5004, [1, 0x1800, 4, 0, 0, 0]),
        );
        k.install_proc_source(&root, output.host_memory_source());
        k.publish_task(1, &root);
        k.processes.insert(1, root);
        k.processes.insert(2, peer);
        k.publish_io_tasks(None);
        let exit = k.drive(&mut output, 1000000).unwrap();
        assert_eq!(exit.code, 7);
        let samples = output.samples.lock().unwrap();
        assert!(!samples.is_empty());
        assert!(samples.iter().all(|thread| *thread != host_thread));
        assert_eq!(k.parallel_rounds, 1);
        assert!(k.cohort_return_syscalls.is_empty());
        let writes = writes.lock().unwrap();
        assert_eq!(writes.len(), 1);
        assert_eq!(writes[0].1, b"peer");
        assert_ne!(
            writes[0].0, host_thread,
            "unrelated accepted SVC executed on the waiting host"
        );
        assert_eq!(k.service_requests, 0);
    }
}

#[test]
fn initial_busy_memory_is_admitted_without_host_cpu_execution() {
    struct Backing(Arc<trames_memory::layout::Layout>);
    impl trames_memory::PageBacking for Backing {
        fn layout(&self) -> Option<Arc<trames_memory::layout::Layout>> {
            Some(self.0.clone())
        }
        fn parallel_key(&self) -> Option<(u64, u64)> {
            Some((self.0.identity(), 0))
        }
        fn check(&self, _: u64) -> Result<(), trames_memory::MemoryError> {
            Ok(())
        }
        fn read(&self, _: usize, out: &mut [u8]) -> Result<(), trames_memory::MemoryError> {
            out.fill(0);
            Ok(())
        }
        fn write(&self, _: usize, _: &[u8]) -> Result<(), trames_memory::MemoryError> {
            Ok(())
        }
        fn sync(&self) -> Result<(), trames_memory::MemoryError> {
            Ok(())
        }
        fn version(&self) -> u64 {
            0
        }
        fn writable(&self) -> bool {
            true
        }
        fn next_page(
            &self,
            _: u64,
        ) -> Result<Arc<dyn trames_memory::PageBacking>, trames_memory::MemoryError> {
            Err(trames_memory::MemoryError::InvalidRange)
        }
    }
    struct Host {
        polls: usize,
        release: Option<trames_memory::layout::LayoutWrite>,
    }
    impl GuestOutput for Host {
        fn source_console(&mut self) -> Arc<dyn trames_vfs::ConsoleIo> {
            Arc::new(trames_vfs::CapturedConsole::default())
        }
        fn poll_host(&mut self, _: &trames_vfs::Vfs) -> std::io::Result<HostState> {
            self.polls += 1;
            if self.polls == 2 {
                drop(self.release.take().unwrap());
            }
            assert!(
                self.polls < 100,
                "original memory release did not wake admission"
            );
            Ok(HostState::Running)
        }
        fn host_interest(&mut self, wait: &mut trames_linux::HostWait) -> std::io::Result<()> {
            wait.until(std::time::Instant::now() + Duration::from_millis(1));
            Ok(())
        }
        fn write(&mut self, _: trames_linux::OutputFd, bytes: &[u8]) -> std::io::Result<usize> {
            Ok(bytes.len())
        }
    }
    for cpus in [1, 4, 12] {
        let mut k = kernel();
        k.cpu_count = cpus;
        k.per_cpu.resize(cpus, Duration::ZERO);
        let mut root = admitted_process(&k);
        executable(&mut root, &[0xd28000e0, 0xd2800ba8, 0xd4000001]);
        let layout = Arc::<trames_memory::layout::Layout>::default();
        root.memory
            .map_backed(
                0x10000,
                vec![Arc::new(Backing(layout.clone()))],
                true,
                Permissions::RW,
                false,
            )
            .unwrap();
        let writer = layout.write();
        assert!(!root.memory.admit_parallel_layouts());
        k.publish_task(1, &root);
        k.processes.insert(1, root);
        let mut host = Host {
            polls: 0,
            release: Some(writer),
        };
        assert_eq!(k.drive(&mut host, 100000).unwrap().code, 7);
        assert!(host.polls >= 2);
        assert_eq!(k.parallel_rounds, 1);
        assert!(k.worker_slices > 0);
        assert!(k.cohort_return_syscalls.is_empty());
    }
}

#[test]
fn explicit_host_cancel_finishes_on_source_without_a_stopped_host_hook() {
    struct Output {
        cancel: bool,
        polls: usize,
        progress: Arc<trames_memory::SharedPage>,
        watchdog: Instant,
    }
    impl GuestOutput for Output {
        fn source_console(&mut self) -> Arc<dyn trames_vfs::ConsoleIo> {
            trames_linux::CapturedOutput::default().source_console()
        }
        fn write(&mut self, _: trames_linux::OutputFd, bytes: &[u8]) -> std::io::Result<usize> {
            Ok(bytes.len())
        }
        fn host_interest(&mut self, wait: &mut trames_linux::HostWait) -> std::io::Result<()> {
            wait.until(std::time::Instant::now() + Duration::from_millis(1));
            Ok(())
        }
        fn poll_host(&mut self, _: &trames_vfs::Vfs) -> std::io::Result<trames_linux::HostState> {
            self.polls += 1;
            self.cancel = self.polls > 1
                && self
                    .progress
                    .with_read(0, 4, |bytes| bytes == 42u32.to_le_bytes())
                || Instant::now() >= self.watchdog;
            Ok(trames_linux::HostState::Running)
        }
        fn cancellation_requested(&self) -> bool {
            self.cancel
        }
    }
    for cpus in [1, 4, 12] {
        let mut k = kernel();
        k.cpu_count = cpus;
        k.per_cpu.resize(cpus, Duration::ZERO);
        let mut root = admitted_process(&k);
        let progress = progress_page(&mut root);
        executable(&mut root, &[0xd2820001, 0xd2800540, 0xb9000020, 0x14000000]);
        k.publish_task(1, &root);
        k.processes.insert(1, root);
        let mut output = Output {
            cancel: false,
            polls: 0,
            progress,
            watchdog: Instant::now() + Duration::from_secs(5),
        };
        assert!(matches!(
            k.drive(&mut output, u64::MAX),
            Err(RuntimeError::Cancelled)
        ));
        assert!(output.polls > 1);
        assert_eq!(
            k.processes.read(&1).memory.read_array::<4>(0x1000).unwrap(),
            42u32.to_le_bytes()
        );
        assert!(k.worker_slices > 0);
    }
}

#[test]
fn closing_preserves_an_accepted_cpu_trap_without_executing_it_on_the_waiting_host() {
    let mut k = kernel();
    let mut root = admitted_process(&k);
    executable(
        &mut root,
        &[
            0xd4000001, 0xd2820001, 0xb9000020, 0xd28000e0, 0xd2800ba8, 0xd4000001,
        ],
    );
    root.cpu.set_x(0, 77);
    root.cpu.set_x(8, 172);
    root.cpu.set_pc(0x4004);
    root.pending_cpu = Some(SliceOutcome::Syscall { instructions: 0 });
    root.seccomp_entry = Some(
        root.seccomp
            .entry_decision(172, root.cpu.pc(), args(&root.cpu)),
    );
    // A later policy publication must not re-evaluate the already accepted SVC.
    let filter = [
        (0x20u16, 0u8, 0u8, 0u32),
        (0x15, 0, 1, 172),
        (6, 0, 0, 0x50007),
        (6, 0, 0, 0x7fff0000),
    ];
    for (index, (op, yes, no, value)) in filter.into_iter().enumerate() {
        let mut bytes = [0; 8];
        bytes[..2].copy_from_slice(&op.to_le_bytes());
        bytes[2] = yes;
        bytes[3] = no;
        bytes[4..].copy_from_slice(&value.to_le_bytes());
        root.memory
            .write_array(0x1400 + index as u64 * 8, bytes)
            .unwrap();
    }
    root.memory
        .write_array(0x1300, [4, 0, 0, 0, 0, 0, 0, 0, 0, 0x14, 0, 0, 0, 0, 0, 0])
        .unwrap();
    root.linux.vfs.credentials.caps.no_new_privs.set();
    assert_eq!(k.seccomp(&mut root, [1, 0, 0x1300, 0, 0, 0]), Ok(0));
    k.publish_task(1, &root);
    k.processes.insert(1, root);
    let control = Arc::new(Control::new(10000));
    let epoch = crate::run_queue::Epoch::with_events(control.clone(), k.workers.events(), true);
    epoch.bind_lifecycle(lifecycle::Lifecycle::capture(&k));
    let (_, _, view) = k.prepare_parallel_views(&[(1, 0)]).unwrap().pop().unwrap();
    epoch.add(k.capture_worker(
        1,
        view,
        &control,
        &mut Default::default(),
        &mut Default::default(),
        &mut Default::default(),
    ));
    control.close(End::Budget);
    k.workers.ensure(0).unwrap();
    k.workers.finish_closed(epoch.clone()).unwrap();
    assert!(epoch.collect_closed(&mut k).is_none());
    {
        let root = k.processes.read(&1);
        assert_eq!(root.cpu.x(0), 77, "closed report executed getpid");
        assert!(matches!(
            root.pending_cpu,
            Some(SliceOutcome::Syscall { .. })
        ));
    }
    assert_eq!(
        k.drive(&mut trames_linux::CapturedOutput::default(), 10000)
            .unwrap()
            .code,
        7
    );
    assert_eq!(
        k.processes.read(&1).memory.read_array::<4>(0x1000).unwrap(),
        1u32.to_le_bytes()
    );
}

#[test]
fn source_backend_fault_closes_without_returning_to_generic_dispatch() {
    let mut k = kernel();
    let mut root = admitted_process(&k);
    executable(&mut root, &[0x14000000]);
    root.pending_cpu = Some(SliceOutcome::Fault(trames_engine::CpuFault::Host(
        "original backend failure".into(),
    )));
    k.publish_task(1, &root);
    k.processes.insert(1, root);
    let control = Arc::new(Control::new(10000));
    let epoch = crate::run_queue::Epoch::with_events(control.clone(), k.workers.events(), true);
    epoch.bind_lifecycle(lifecycle::Lifecycle::capture(&k));
    let (_, _, view) = k.prepare_parallel_views(&[(1, 0)]).unwrap().pop().unwrap();
    epoch.add(k.capture_worker(
        1,
        view,
        &control,
        &mut Default::default(),
        &mut Default::default(),
        &mut Default::default(),
    ));
    k.workers.ensure(0).unwrap();
    k.workers.launch(0, epoch.clone()).unwrap();
    assert!(matches!(
        k.workers.event_timeout(Duration::from_secs(2)).unwrap(),
        Some(crate::workers::Event::EpochStopped(0))
    ));
    assert_eq!(control.end(), Some(End::Failed));
    k.workers.finish_closed(epoch.clone()).unwrap();
    assert!(
        matches!(epoch.collect_closed(&mut k), Some(RuntimeError::Backend(error)) if error == "original backend failure")
    );
    assert!(k.cohort_return_syscalls.is_empty());
    assert_eq!(k.serviced_syscalls, 0);
}

#[test]
fn single_cpu_bootstrap_opens_original_embedding_terminal_zero_without_owner_return() {
    let mut k = kernel();
    k.profile_syscalls = true;
    let mut root = admitted_process(&k);
    root.linux.vfs.enable_terminal().unwrap();
    root.memory.write(0x1000, b"/dev/tty\0").unwrap();
    root.cpu.set_x(0, (-100i64) as u64);
    root.cpu.set_x(1, 0x1000);
    root.cpu.set_x(2, 0x20002);
    root.cpu.set_x(8, 56);
    executable(
        &mut root,
        &[0xd4000001, 0xaa0003f3, 0xd2800000, 0xd2800ba8, 0xd4000001],
    );
    k.publish_task(1, &root);
    k.processes.insert(1, root);
    assert_eq!(
        k.drive(&mut trames_linux::CapturedOutput::default(), 100000)
            .unwrap()
            .code,
        0
    );
    assert!((3..trames_vfs::MAX_FDS as u64).contains(&k.processes.read(&1).cpu.x(19)));
    assert_eq!(k.parallel_rounds, 1);
    assert!(k.cohort_return_syscalls.is_empty());
    assert_eq!(k.serviced_syscalls, 0);
}

#[test]
fn reserved_budget_waits_for_actual_source_cpu_quiescence_and_refunds_unused_credit() {
    let mut k = kernel();
    for pid in [1, 2] {
        let mut task = admitted_process(&k);
        task.tgid = pid;
        executable(&mut task, &[0x14000000]);
        k.publish_task(pid, &task);
        k.processes.insert(pid, task);
    }
    let control = Arc::new(Control::with_budget(10, true));
    let epoch = crate::run_queue::Epoch::with_events(control.clone(), k.workers.events(), true);
    epoch.bind_lifecycle(lifecycle::Lifecycle::capture(&k));
    for (pid, _, view) in k.prepare_parallel_views(&[(1, 0), (2, 0)]).unwrap() {
        epoch.add(k.capture_worker(
            pid,
            view,
            &control,
            &mut Default::default(),
            &mut Default::default(),
            &mut Default::default(),
        ));
    }
    let mut first = epoch.take(0).unwrap();
    assert_eq!(control.claim(), Some(10));
    assert_eq!(control.claim(), None);
    assert_eq!(
        control.end(),
        None,
        "unallocated zero is not retired budget"
    );
    control.refund(4);
    first.stats.instructions = 6;
    epoch.park(first, None);
    let mut second = epoch.take(0).unwrap();
    assert_eq!(control.claim(), Some(4));
    assert_eq!(control.claim(), None);
    assert_eq!(
        control.end(),
        None,
        "the second CPU still owns its reservation"
    );
    second.stats.instructions = 4;
    epoch.park(second, None);
    assert!(epoch.take(0).is_none());
    assert_eq!(control.end(), Some(End::Budget));
    k.workers.ensure(0).unwrap();
    k.workers.finish_closed(epoch.clone()).unwrap();
    assert!(epoch.collect_closed(&mut k).is_none());
    assert_eq!(k.instructions, 10);
}

#[test]
fn a_live_source_waits_for_its_host_event_without_periodic_task_scans() {
    struct Host {
        deadline: Instant,
        polls: usize,
    }
    impl GuestOutput for Host {
        fn source_console(&mut self) -> Arc<dyn trames_vfs::ConsoleIo> {
            Arc::new(trames_vfs::CapturedConsole::default())
        }
        fn host_interest(&mut self, wait: &mut trames_linux::HostWait) -> std::io::Result<()> {
            wait.until(self.deadline);
            Ok(())
        }
        fn poll_host(&mut self, _: &trames_vfs::Vfs) -> std::io::Result<HostState> {
            self.polls += 1;
            Ok(HostState::from_cancelled(Instant::now() >= self.deadline))
        }
        fn write(&mut self, _: trames_linux::OutputFd, bytes: &[u8]) -> std::io::Result<usize> {
            Ok(bytes.len())
        }
    }
    for cpus in [1, 4, 12] {
        let mut k = kernel();
        k.cpu_count = cpus;
        k.per_cpu.resize(cpus, Duration::ZERO);
        let mut root = admitted_process(&k);
        executable(&mut root, &[0x14000000]);
        k.publish_task(1, &root);
        k.processes.insert(1, root);
        let mut host = Host {
            deadline: Instant::now() + Duration::from_millis(80),
            polls: 0,
        };
        assert!(matches!(
            k.drive(&mut host, u64::MAX),
            Err(RuntimeError::Cancelled)
        ));
        assert!(
            host.polls <= 4,
            "unexpected periodic host polls: {}",
            host.polls
        );
        assert!(k.source_completed);
        assert!(k.cohort_return_syscalls.is_empty());
    }
}

#[test]
fn an_initially_paused_source_resumes_from_the_original_host_notification() {
    use std::sync::atomic::Ordering;
    struct Host {
        paused: Arc<std::sync::atomic::AtomicBool>,
        observed: std::sync::mpsc::Sender<()>,
        bound: Option<std::sync::mpsc::Sender<Arc<trames_linux::HostWake>>>,
        deadline: Instant,
    }
    impl GuestOutput for Host {
        fn source_console(&mut self) -> Arc<dyn trames_vfs::ConsoleIo> {
            Arc::new(trames_vfs::CapturedConsole::default())
        }
        fn bind_host_wake(&mut self, wake: Arc<trames_linux::HostWake>) {
            if let Some(bound) = self.bound.take() {
                bound.send(wake).unwrap();
            }
        }
        fn paused(&self) -> bool {
            let paused = self.paused.load(Ordering::Relaxed);
            if paused {
                let _ = self.observed.send(());
            }
            paused
        }
        fn host_interest(&mut self, wait: &mut trames_linux::HostWait) -> std::io::Result<()> {
            wait.until(self.deadline);
            Ok(())
        }
        fn poll_host(&mut self, _: &trames_vfs::Vfs) -> std::io::Result<HostState> {
            Ok(HostState::from_cancelled(Instant::now() >= self.deadline))
        }
        fn write(&mut self, _: trames_linux::OutputFd, bytes: &[u8]) -> std::io::Result<usize> {
            Ok(bytes.len())
        }
    }
    let mut k = kernel();
    let mut root = admitted_process(&k);
    executable(&mut root, &[0xd28000e0, 0xd2800ba8, 0xd4000001]);
    k.publish_task(1, &root);
    k.processes.insert(1, root);
    let paused = Arc::new(std::sync::atomic::AtomicBool::new(true));
    let (bound, binding) = std::sync::mpsc::channel();
    let (observed, observation) = std::sync::mpsc::channel();
    let resume = paused.clone();
    let producer = std::thread::spawn(move || {
        let wake: Arc<trames_linux::HostWake> =
            binding.recv_timeout(Duration::from_secs(2)).unwrap();
        observation.recv_timeout(Duration::from_secs(2)).unwrap();
        resume.store(false, Ordering::Relaxed);
        wake.notify();
    });
    let mut host = Host {
        paused,
        observed,
        bound: Some(bound),
        deadline: Instant::now() + Duration::from_secs(3),
    };
    assert_eq!(k.drive(&mut host, 100000).unwrap().code, 7);
    producer.join().unwrap();
    assert!(k.source_completed);
}
