// SPDX-License-Identifier: GPL-3.0-or-later
//! Mapping commits quiesce actual mm/backing domains. Other jobs, translations,
//! pending I/O and native calls stay in the existing execution queue.
use super::*;

impl<C: Cpu> Kernel<C> {
    #[cfg(all(test, trames_interpreter_conformance))]
    pub(super) fn vm_checkpoint(
        &mut self,
        epoch: &crate::run_queue::Epoch<C>,
        mut checkpoint: crate::run_queue::Checkpoint<C>,
        io: &mut impl GuestOutput,
        proc_waits: &mut Vec<super::proc::ProcReadWait<C>>,
    ) -> Result<bool, RuntimeError> {
        let _custody = match tasks::admit(&checkpoint.jobs, &epoch.io_target) {
            Ok(custody) => custody,
            Err(wait) => {
                epoch.defer_checkpoint(checkpoint, wait.signal, wait.subscriptions);
                return Ok(true);
            }
        };
        let began = Instant::now();
        let wait = checkpoint
            .quiescent
            .saturating_duration_since(checkpoint.requested);
        self.vm_checkpoint_time[0] += wait;
        self.vm_checkpoint_time[1] += checkpoint
            .taken
            .saturating_duration_since(checkpoint.quiescent);
        let bucket = [5, 20, 100, 500, 1000, 2000, 5000]
            .iter()
            .position(|&limit| wait.as_micros() < limit)
            .unwrap_or(7);
        self.vm_checkpoint_wait_bins[bucket] += 1;
        // Every CPU/service of these mm/backing domains has returned. Their
        // original task/mm custody is held here; no unrelated Memory is inspected.
        for job in &mut checkpoint.jobs {
            drop(job.work.memory.take());
            job.work.cpu.clear_exclusive();
        }
        let lifecycle_only = checkpoint.jobs.iter().any(|job| job.checkpoint.is_some())
            && checkpoint
                .jobs
                .iter()
                .filter(|job| job.checkpoint.is_some())
                .all(|job| job.structural_call().is_some_and(|call| call.task()));
        if checkpoint.proc_reads && !lifecycle_only {
            let mut wait = self.proc_read_wait();
            let mut ids = std::collections::BTreeSet::new();
            let mut pending = false;
            for job in &checkpoint.jobs {
                let memory = &self.processes.read(&job.work.pid).memory;
                if ids.insert(memory.coordinator_ownership().0) {
                    wait.subscriptions
                        .push(memory.subscribe_parallel_idle(&wait.signal));
                    pending |= !memory.parallel_views_quiescent();
                }
            }
            if pending {
                wait.checkpoint = Some(checkpoint);
                proc_waits.push(wait);
                return Ok(true);
            }
        }
        let result = (|| {
            for done in epoch.take_retired() {
                self.accept_source_return(done)?;
            }
            self.process_exits(Some(epoch))?;
            let metadata = checkpoint.proc_reads
                || !checkpoint.mm_only
                || checkpoint.jobs.iter().any(|job| job.checkpoint.is_some());
            let mut created = Vec::new();
            let mut committed = std::collections::BTreeSet::new();
            for job in checkpoint.jobs.iter().filter(|_| metadata) {
                let p = &mut self.processes.get_mut(&job.work.pid).unwrap();
                let id = p.memory.coordinator_ownership().0;
                if committed.insert(id) {
                    if !p.memory.parallel_views_quiescent() {
                        if !lifecycle_only {
                            return Ok(false);
                        }
                        p.memory.commit_retired_parallel()?;
                        if checkpoint.proc_reads {
                            // Clone/exec can proceed with an accepted external
                            // borrower. Preserve the original mm's pending read;
                            // resume lifecycle first, then take a pure read
                            // scope. Waiting for idle here would miss external
                            // release while the resumed CPU Views still exist.
                            self.proc_source
                                .as_ref()
                                .unwrap()
                                .request_read(p.memory.memory_report());
                        }
                    } else {
                        p.memory.commit_parallel()?;
                        if checkpoint.proc_reads {
                            assert!(p.memory.activate_proc_reads());
                        }
                    }
                }
            }
            self.vm_checkpoint_groups += 1;
            self.vm_checkpoint_spaces += if checkpoint.mm_only {
                checkpoint.ids.len() as u64
            } else {
                committed.len() as u64
            };
            let elapsed = began.elapsed();
            self.parallel_memory_time += elapsed;
            self.vm_checkpoint_time[2] += elapsed;
            // Already exclusive: coalesce a short run of structural calls
            // instead of waking every peer between consecutive VM syscalls.
            // The hardware timer bounds the window even if guest code computes
            // forever. Other exits retain ordinary worker authority and order.
            if !self.exec_checkpoint(epoch, &mut checkpoint, io, &mut created)? {
                return Ok(false);
            }
            for job in &mut checkpoint.jobs {
                if job
                    .work
                    .syscalls
                    .as_ref()
                    .is_some_and(|s| s.io_signals.lifecycle().termination().is_some())
                {
                    job.checkpoint = None;
                    continue;
                }
                let Some(outcome) = job.checkpoint.take() else {
                    continue;
                };
                assert!(matches!(outcome, SliceOutcome::Syscall { .. }));
                let pid = job.work.pid;
                let mut p = self.processes.checkout(&pid).expect("paused task");
                p.linux.vfs.sync_task_namespaces();

                p.cpu = std::mem::take(&mut job.work.cpu);
                let control = p.signals.io.lifecycle().enter(&p.signals.io, pid);
                p.state = State::Ready;
                if p.seccomp.mode() != 0 {
                    let entry = job.seccomp_entry.take().unwrap_or_else(|| {
                        p.seccomp
                            .entry_decision(p.cpu.x(8) as u32, p.cpu.pc(), args(&p.cpu))
                    });
                    let allowed = entry.allowed();
                    p.seccomp_entry = Some(entry);
                    if !allowed {
                        // Signal/kill/broker effects retain their full owner
                        // boundary. Preserve this entry and its BPF result for
                        // the ordinary joined call, without replaying either.
                        job.checkpoint = Some(outcome);
                        job.work.cpu = std::mem::take(&mut p.cpu);
                        self.processes.insert(pid, p);
                        return Ok(false);
                    }
                }
                if matches!(
                    crate::structural::Call::from_cpu(&p.cpu),
                    Some(crate::structural::Call::Clone | crate::structural::Call::Clone3)
                ) {
                    // Copy actual signal state before inheriting it. Mapping
                    // custody alone did not need this task-state handoff.
                    p.signals.finish_io();
                    let a = args(&p.cpu);
                    let call_began = Instant::now();
                    p.trace = std::mem::take(&mut job.work.trace);
                    let number = p.cpu.x(8) as u32;
                    self.call(pid, &mut p, number, a, io);
                    job.work.trace = std::mem::take(&mut p.trace);
                    self.vm_checkpoint_time[3] += call_began.elapsed();
                    let value = p.cpu.x(0);
                    if value != 0 && value <= i32::MAX as u64 {
                        // Translate the actual successful syscall result in its
                        // original namespace, never guess the allocator's ID.
                        let child = p
                            .linux
                            .vfs
                            .global_pid(value as u32)
                            .expect("created child identity");
                        assert!(self.processes.contains_key(&child));
                        created.push(child);
                    }
                    if let State::Completion(release) = &p.state {
                        let wait = crate::run_queue::CompletionWait::new(release.clone());
                        if let Some(snapshot) = &job.work.syscalls {
                            wait.bind(
                                &snapshot.io_signals,
                                snapshot.io_wake.as_ref().expect("bound parent"),
                            );
                        }
                        job.waiting = Some(crate::run_queue::WaitState::Completion(wait));
                    }
                    p.signals.begin_io();
                    job.work.cpu = std::mem::take(&mut p.cpu);
                    control.finish(job.stop_hold());
                    self.processes.insert(pid, p);
                    continue;
                }
                let call = crate::structural::Call::from_cpu(&p.cpu)
                    .and_then(|call| call.memory())
                    .expect("original memory operation");
                let number = call.number();
                let args = std::array::from_fn(|i| p.cpu.x(i));
                self.vm_checkpoint_calls[call.index()] += 1;
                let call_began = Instant::now();
                p.trace = std::mem::take(&mut job.work.trace);
                self.call(pid, &mut p, number, args, io);
                job.work.trace = std::mem::take(&mut p.trace);
                self.vm_checkpoint_time[3] += call_began.elapsed();
                if number == 1 && p.byte_wait.is_some() {
                    job.io = p.byte_wait.take();
                    p.state = State::Ready;
                }
                assert!(matches!(p.state, State::Ready), "mapping call cannot park");
                self.vm_local_syscalls += 1;
                // The compatibility handler can finish the accepted operation,
                // but it cannot execute a subsequent guest instruction. Native
                // batching exists only on the original execution worker.
                job.work.cpu = std::mem::take(&mut p.cpu);
                control.finish(job.stop_hold());
                if let Some(task) = p.signals.io.cgroup() {
                    task.acknowledge();
                }
                self.processes.insert(pid, p);
            }
            // Prepare children before their creators. Freezing a writable COW
            // page materializes one private copy; put it in the new mm so the
            // existing parent keeps its physical storage and hardware mappings.
            // All affected actors remain paused until every View is installed.
            let mut members: Vec<_> = created
                .iter()
                .map(|&id| (id, self.processes.read(&id).last_cpu))
                .collect();
            members.extend(
                checkpoint
                    .jobs
                    .iter()
                    .map(|job| (job.work.pid, job.stats.worker)),
            );
            let began = Instant::now();
            let mut views = if !metadata {
                let views: Option<Vec<_>> = members
                    .iter()
                    .map(|&(pid, slot)| {
                        let mut view =
                            Box::new(self.processes.read(&pid).memory.current_parallel_view()?);
                        C::prepare_hardware_view(&mut view);
                        Some((pid, slot, view))
                    })
                    .collect();
                let Some(views) = views else {
                    return Ok(false);
                };
                views
            } else {
                let Some(views) = self.prepare_views(&members, lifecycle_only) else {
                    return Ok(false); // changed to an excluded backing; join once
                };
                views
            };
            self.admit_private_views(&mut views);
            let mut files = trames_vfs::FileEpoch::default();
            let mut urings = trames_linux::UringEpoch::default();
            let mut network = trames_vfs::NetworkEpoch::default();
            for (pid, _, view) in views {
                if let Some(job) = checkpoint.jobs.iter_mut().find(|job| job.work.pid == pid) {
                    job.work.memory = Some(view);
                } else {
                    let job = self.capture_worker(
                        pid,
                        view,
                        &epoch.control,
                        &mut files,
                        &mut urings,
                        &mut network,
                    );
                    epoch.admit_checkpoint(&mut checkpoint, job);
                }
            }
            let elapsed = began.elapsed();
            self.parallel_memory_time += elapsed;
            self.vm_checkpoint_time[4] += elapsed;
            Ok(true)
        })();
        let resume_began = Instant::now();
        epoch.restore_checkpoint(checkpoint, matches!(result, Ok(true)));
        self.vm_checkpoint_time[5] += resume_began.elapsed();
        result
    }

    // ARCHITECTURE: this caller waits for embedding events and source completion.
    // Guest progress must stay on existing execution/I/O workers and original
    // task/mm/OFD resources. Never add guest checkpoint dispatch, task/deadline
    // scans, periodic retries or a fallback that stops every CPU here. Bind the
    // actual resource and its readiness when a new operation needs worker support.
    pub(super) fn wait_source(
        &mut self,
        epoch: &crate::run_queue::Epoch<C>,
        io: &mut impl GuestOutput,
    ) -> Result<(), RuntimeError> {
        let mut wait = match self.host_wait.take() {
            Some(wait) => wait,
            None => trames_linux::HostWait::new().map_err(|e| RuntimeError::HostIo(Arc::new(e)))?,
        };
        let wake = wait.wake();
        epoch.control.bind_host(wake.clone());
        io.bind_host_wake(wake);
        epoch.bind_host_wait(io.waits_for_host());
        while !epoch.control.closing() {
            wait.begin();
            io.host_interest(&mut wait)
                .map_err(|e| RuntimeError::HostIo(Arc::new(e)))?;
            self.cohort_live_control(epoch, &[], io)?;
            if epoch.control.closing() {
                break;
            }
            wait.wait().map_err(|e| RuntimeError::HostIo(Arc::new(e)))?;
        }
        self.host_wait = Some(wait);
        Ok(())
    }
    #[cfg(all(test, trames_interpreter_conformance))]
    pub(super) fn cohort_control(
        &mut self,
        _members: &[(u32, usize)],
        io: &mut impl GuestOutput,
    ) -> Result<bool, RuntimeError> {
        self.cohort_control_inner(None, _members, io)
    }
    pub(super) fn cohort_live_control(
        &mut self,
        epoch: &crate::run_queue::Epoch<C>,
        _members: &[(u32, usize)],
        io: &mut impl GuestOutput,
    ) -> Result<bool, RuntimeError> {
        self.cohort_control_inner(Some(epoch), _members, io)
    }
    fn cohort_control_inner(
        &mut self,
        epoch: Option<&crate::run_queue::Epoch<C>>,
        _members: &[(u32, usize)],
        io: &mut impl GuestOutput,
    ) -> Result<bool, RuntimeError> {
        self.persistent_control_checks += 1;
        self.bind_host_context();
        if let Some(host) = &self.host_context {
            let state = io
                .poll_host(&host.vfs)
                .map_err(|_| RuntimeError::Arguments("host session poll failed"))?;
            if state == HostState::Cancelled || io.cancellation_requested() {
                if let Some(epoch) = epoch {
                    epoch.cancel();
                }
                return Err(RuntimeError::Cancelled);
            }
            if let Some(epoch) = epoch {
                epoch.pause_host(io.paused());
            }
            if let Some(signal) = io.root_signal() {
                host.root.host_signal(signal);
            }
            while let Some(request) = io.host_spawn() {
                if let Some(epoch) = epoch {
                    epoch.submit_host(request);
                } else {
                    self.host_launches.submit(request);
                }
            }
            while let Some((group, signal)) = io.host_signal() {
                host.directory.host_signal_group(group, signal);
            }
        }
        // Every original product actor was admitted before launch. Later
        // births publish through source admission, including initially frozen
        // or sleeping tasks. Host polling never revives a cold owner snapshot.
        if epoch.is_some_and(|epoch| epoch.source_session()) {
            return Ok(false);
        }
        #[cfg(all(test, trames_interpreter_conformance))]
        {
            self.compatibility_control(epoch, _members, io)
        }
        #[cfg(not(all(test, trames_interpreter_conformance)))]
        unreachable!("live control requires original source resources")
    }
    #[cfg(all(test, trames_interpreter_conformance))]
    fn compatibility_control(
        &self,
        epoch: Option<&crate::run_queue::Epoch<C>>,
        members: &[(u32, usize)],
        io: &mut impl GuestOutput,
    ) -> Result<bool, RuntimeError> {
        let now = Instant::now();
        let members: std::collections::BTreeSet<_> = members.iter().map(|(pid, _)| *pid).collect();
        Ok(self.processes.iter().any(|(pid, p)| {
            if p.frozen(pid) {
                return false;
            }
            // Read queue membership before the original exit flag. A source
            // CPU publishes exit before removing its queue member; the queue
            // mutex orders this later liveness read. Checking live first could
            // misclassify the cold Ready projection while its cleanup waits.
            let controlled =
                members.contains(&pid) || epoch.is_some_and(|epoch| epoch.controls(pid));
            if epoch.is_some_and(|epoch| epoch.source_lifecycle())
                && p.signals.io.tgid() != 0
                && !p.signals.io.live()
            {
                return false;
            }
            if controlled {
                // An excluded original resource still needs its actual owner;
                // a stopped task cannot acknowledge before that work finishes.
                return p.stopped() && p.stop_held() && !p.control_candidate(pid);
            }
            if p.stopped() && !p.stop_held() && p.pending_bits() & (1 << 8) == 0 {
                return false;
            }
            match p.state {
                // A masked epoll wait retains its signal-mask authority on the
                // owner. Its blocked state alone is not a reason to stop peers.
                State::Blocked(22 | 441, args) => {
                    let pending = p.pending_bits();
                    pending & !p.signals.mask != 0
                        || p.poll_deadline.is_some_and(|d| d <= now)
                        || p.linux
                            .vfs
                            .epoll_ready_signals(args[0] as u32, pending, |kind, events| {
                                Ok(match kind {
                                    FdKind::Stdin => Some((
                                        if io.stdin_ready().map_err(|_| Errno(5))? {
                                            events & 1
                                        } else {
                                            0
                                        },
                                        [0; 2],
                                    )),
                                    FdKind::Terminal => None,
                                    _ => None,
                                })
                            })
                            .unwrap_or(true)
                }
                State::Ready | State::Gpu { .. } | State::Blocked(..) => true,
                State::ClockSleep(ref w) => w.ready(),
                State::Sleep(d, _) => d <= now,
                State::Futex { deadline, .. } | State::Sigwait { deadline, .. } => {
                    deadline.is_some_and(|d| d <= now)
                }
                _ => false,
            }
        }))
    }
}

#[cfg(all(test, trames_interpreter_conformance))]
mod tests {
    use trames_cpu::Cpu;
    type Process = crate::process::Process<Cpu>;

    use super::*;
    use std::sync::{
        atomic::{AtomicBool, AtomicU64, Ordering},
        mpsc, Mutex,
    };
    use trames_memory::{MemoryError, PageBacking, Permissions, SharedPage, PAGE_SIZE};

    #[test]
    fn masked_owner_epoll_joins_only_for_events_signals_or_timeout_without_consuming_edges() {
        let mut kernel = super::super::tests::kernel();
        let mut owner = super::super::tests::process();
        let event = owner.linux.vfs.eventfd(0, 0).unwrap();
        let epoll = owner.linux.vfs.epoll_create(0).unwrap();
        owner
            .linux
            .vfs
            .epoll_ctl(epoll, 1, event, 0xc0000001, 42)
            .unwrap();
        owner.state = State::Blocked(22, [epoll as u64, 0x1000, 1, u64::MAX, 0x2000, 8]);
        owner.signals.wait_mask = Some(0);
        owner.signals.mask = 1 << 11;
        kernel.processes.insert(1, owner);
        let mut output = trames_linux::CapturedOutput::default();
        assert!(!kernel.cohort_control(&[(2, 0)], &mut output).unwrap());
        kernel
            .processes
            .get_mut(&1)
            .unwrap()
            .linux
            .vfs
            .write(event, &1u64.to_le_bytes())
            .unwrap();
        for _ in 0..3 {
            assert!(kernel.cohort_control(&[(2, 0)], &mut output).unwrap());
        }
        assert_eq!(
            kernel
                .processes
                .read(&1)
                .linux
                .vfs
                .epoll_wait(epoll, 1, |_, _| Ok(None))
                .unwrap(),
            vec![(1, 42)]
        );
        assert!(!kernel.cohort_control(&[(2, 0)], &mut output).unwrap());
        kernel.processes.get_mut(&1).unwrap().poll_deadline = Some(Instant::now());
        assert!(kernel.cohort_control(&[(2, 0)], &mut output).unwrap());
        let mut custody = kernel.processes.get_mut(&1).unwrap();
        let owner = &mut *custody;
        owner.poll_deadline = None;
        Kernel::<Cpu>::queue_one(1, owner, 10, 0);
        drop(custody);
        assert!(kernel.cohort_control(&[(2, 0)], &mut output).unwrap());
        assert_eq!(kernel.processes.read(&1).signals.wait_mask, Some(0));
        assert_eq!(kernel.processes.read(&1).signals.mask, 1 << 11);
    }

    struct Page {
        bytes: Arc<SharedPage>,
        gate: Option<(mpsc::SyncSender<()>, std::sync::Mutex<mpsc::Receiver<()>>)>,
    }
    impl Drop for Page {
        fn drop(&mut self) {
            if let Some((entered, release)) = &self.gate {
                entered.send(()).unwrap();
                release
                    .lock()
                    .unwrap()
                    .recv_timeout(Duration::from_secs(3))
                    .unwrap();
            }
        }
    }
    impl PageBacking for Page {
        fn parallel_key(&self) -> Option<(u64, u64)> {
            Some((Arc::as_ptr(&self.bytes) as usize as u64, 0))
        }
        fn shared_page(&self) -> Option<Arc<SharedPage>> {
            Some(self.bytes.clone())
        }
        fn check(&self, _: u64) -> Result<(), MemoryError> {
            Ok(())
        }
        fn read(&self, offset: usize, out: &mut [u8]) -> Result<(), MemoryError> {
            self.bytes
                .with_read(offset, out.len(), |bytes| out.copy_from_slice(bytes));
            Ok(())
        }
        fn write(&self, offset: usize, bytes: &[u8]) -> Result<(), MemoryError> {
            self.bytes
                .with_write(offset, bytes.len(), |out| out.copy_from_slice(bytes));
            Ok(())
        }
        fn writable(&self) -> bool {
            true
        }
        fn sync(&self) -> Result<(), MemoryError> {
            Ok(())
        }
        fn version(&self) -> u64 {
            self.bytes.revision()
        }
        fn publish_write(&self, _: usize, _: usize) -> Result<(), MemoryError> {
            Ok(())
        }
        fn next_page(&self, _: u64) -> Result<Arc<dyn PageBacking>, MemoryError> {
            Err(MemoryError::InvalidRange)
        }
    }
    #[test]
    fn source_exit_publishes_backing_when_only_an_undispatched_mm_owner_remains() {
        struct Legacy {
            bytes: Mutex<[u8; PAGE_SIZE as usize]>,
            version: AtomicU64,
            identity: u64,
        }
        impl PageBacking for Legacy {
            fn parallel_key(&self) -> Option<(u64, u64)> {
                Some((self.identity, 0))
            }
            fn check(&self, _: u64) -> Result<(), MemoryError> {
                Ok(())
            }
            fn read(&self, offset: usize, out: &mut [u8]) -> Result<(), MemoryError> {
                out.copy_from_slice(&self.bytes.lock().unwrap()[offset..offset + out.len()]);
                Ok(())
            }
            fn write(&self, offset: usize, bytes: &[u8]) -> Result<(), MemoryError> {
                self.bytes.lock().unwrap()[offset..offset + bytes.len()].copy_from_slice(bytes);
                self.version.fetch_add(1, Ordering::Relaxed);
                trames_memory::backing_changed();
                Ok(())
            }
            fn writable(&self) -> bool {
                true
            }
            fn sync(&self) -> Result<(), MemoryError> {
                Ok(())
            }
            fn version(&self) -> u64 {
                self.version.load(Ordering::Relaxed)
            }
            fn next_page(&self, _: u64) -> Result<Arc<dyn PageBacking>, MemoryError> {
                Err(MemoryError::InvalidRange)
            }
        }
        let mut k = super::super::tests::kernel();
        k.cpu_count = 2;
        k.workers = crate::workers::Pool::new(2);
        k.per_cpu = vec![Duration::ZERO; 2];
        let mut parent = super::super::tests::process();
        parent.signals.io.scheduling.set_affinity(3);
        let [reader, _writer] = parent.linux.vfs.pipe(0).unwrap();
        let mov = |register: u32, value: u32| 0xd2800000 | value << 5 | register;
        for (i, word) in [
            mov(0, reader),
            mov(1, 0x1300),
            mov(2, 1),
            mov(8, 63),
            0xd4000001,
            0x14000000,
        ]
        .into_iter()
        .enumerate()
        {
            parent
                .memory
                .write_array(0x4200 + i as u64 * 4, word.to_le_bytes())
                .unwrap();
        }
        parent.cpu.pc = 0x4200;
        parent
            .memory
            .protect(0x4000, PAGE_SIZE, Permissions::RX)
            .unwrap();
        let mut output = trames_linux::CapturedOutput::default();
        // No CLONE_VM: the parent cannot accidentally publish the child's
        // legacy backing through its own independent address space.
        k.syscall(1, &mut parent, 220, [0x4011, 0, 0, 0, 0, 0], &mut output)
            .unwrap();
        k.processes.insert(1, parent);
        let mut child = k.processes.remove(&2).unwrap();
        child.memory.unmap(0x6000, PAGE_SIZE).unwrap();
        let backing = Arc::new(Legacy {
            bytes: Mutex::new([0; PAGE_SIZE as usize]),
            version: AtomicU64::new(0),
            identity: trames_memory::new_backing_identity(),
        });
        child
            .memory
            .map_backed(0x6000, vec![backing.clone()], true, Permissions::RW, false)
            .unwrap();
        child
            .memory
            .protect(0x4000, PAGE_SIZE, Permissions::RW)
            .unwrap();
        code(
            &mut child,
            &[
                mov(1, 0x6000),
                mov(0, 99),
                0xf9000020,
                mov(0, 23),
                mov(8, 93),
                0xd4000001,
            ],
        );
        child.cpu.pc = 0x4000;
        k.syscall(2, &mut child, 220, [0x10b00, 0, 0, 0, 0, 0], &mut output)
            .unwrap();
        let mut peer = k.processes.get_mut(&3).unwrap();
        peer.state = State::Suspend(0);
        peer.linux.trace = true; // manually excluded original task, with diagnostics enabled
        drop(peer);
        k.processes.insert(2, child);
        assert!(k.parallel_epoch(&mut output, 100000000, false).unwrap());
        assert!(matches!(k.processes.read(&2).state, State::Zombie(status) if status == 23 << 8));
        assert!(
            k.processes.read(&2).memory.read_array::<1>(0x6000).is_err(),
            "returned wrapper was not collected during the cohort"
        );
        assert_eq!(
            u64::from_le_bytes(backing.bytes.lock().unwrap()[..8].try_into().unwrap()),
            99
        );
        assert_eq!(
            u64::from_le_bytes(k.processes.read(&3).memory.read_array(0x6000).unwrap()),
            99
        );
    }
    fn map(
        p: &mut Process,
        base: u64,
        bytes: Arc<SharedPage>,
        gate: Option<(mpsc::SyncSender<()>, mpsc::Receiver<()>)>,
    ) {
        p.memory.unmap(base, PAGE_SIZE).unwrap();
        p.memory
            .map_backed(
                base,
                vec![Arc::new(Page {
                    bytes,
                    gate: gate.map(|(entered, release)| (entered, std::sync::Mutex::new(release))),
                })],
                true,
                Permissions::RW,
                false,
            )
            .unwrap();
    }
    fn code(p: &mut Process, words: &[u32]) {
        let bytes: Vec<_> = words.iter().copied().flat_map(u32::to_le_bytes).collect();
        p.memory.write(0x4000, &bytes).unwrap();
        p.memory
            .protect(0x4000, PAGE_SIZE, Permissions::RX)
            .unwrap();
    }
    fn count(page: &SharedPage) -> u64 {
        page.with_read(0, 8, |bytes| u64::from_le_bytes(bytes.try_into().unwrap()))
    }
    struct Stop(Arc<AtomicBool>);
    impl GuestOutput for Stop {
        // Explicit observation clock for this white-box fixture only.
        fn host_interest(&mut self, wait: &mut trames_linux::HostWait) -> std::io::Result<()> {
            wait.until(Instant::now() + Duration::from_millis(1));
            Ok(())
        }

        fn source_console(&mut self) -> std::sync::Arc<dyn trames_vfs::ConsoleIo> {
            std::sync::Arc::new(trames_vfs::CapturedConsole::default())
        }

        fn poll_host(&mut self, _: &trames_vfs::Vfs) -> std::io::Result<trames_linux::HostState> {
            Ok(trames_linux::HostState::from_cancelled(
                self.0.load(Ordering::Relaxed),
            ))
        }

        fn write(&mut self, _: OutputFd, bytes: &[u8]) -> std::io::Result<usize> {
            Ok(bytes.len())
        }
    }

    #[test]
    fn additive_mmap_reaches_a_running_clone_vm_peer_without_a_vm_checkpoint() {
        struct Completed {
            bytes: Arc<SharedPage>,
            deadline: Instant,
        }
        impl GuestOutput for Completed {
            // Explicit observation clock for this white-box fixture only.
            fn host_interest(&mut self, wait: &mut trames_linux::HostWait) -> std::io::Result<()> {
                wait.until(Instant::now() + Duration::from_millis(1));
                Ok(())
            }

            fn source_console(&mut self) -> std::sync::Arc<dyn trames_vfs::ConsoleIo> {
                std::sync::Arc::new(trames_vfs::CapturedConsole::default())
            }

            fn poll_host(
                &mut self,
                _: &trames_vfs::Vfs,
            ) -> std::io::Result<trames_linux::HostState> {
                Ok(trames_linux::HostState::from_cancelled(
                    self.bytes.with_read(8, 8, |b| b == 17u64.to_le_bytes())
                        || Instant::now() >= self.deadline,
                ))
            }
            fn write(&mut self, _: OutputFd, b: &[u8]) -> std::io::Result<usize> {
                Ok(b.len())
            }
        }
        let mut k = super::super::tests::kernel();
        k.cpu_count = 2;
        k.workers = crate::workers::Pool::new(2);
        k.per_cpu = vec![Duration::ZERO; 2];
        let mut a = super::super::tests::process();
        let bytes = Arc::new(SharedPage::new([0; PAGE_SIZE as usize]));
        map(&mut a, 0x1000, bytes.clone(), None);
        // mmap; store 17 in the returned mapping; STLR its pointer; keep running.
        let mut words = vec![
            0xd4000001, 0xaa0003e2, 0xd2800221, 0xf9000041, 0xd2820003, 0xc89ffc62, 0x14000000,
        ];
        words.resize(64, 0xd503201f);
        // LDAR pointer; wait for publication; load through the original View.
        words.extend([
            0xd2820003, 0xc8dffc60, 0xb4ffffe0, 0xf9400001, 0xf9000461, 0xf9400862, 0x91000442,
            0xf9000862, 0x17fffffd,
        ]);
        code(&mut a, &words);
        for (i, x) in [0, 1 << 21, 3, 0x22, u64::MAX, 0].into_iter().enumerate() {
            a.cpu.set_x(i, x);
        }
        a.cpu.set_x(8, 222);
        let memory = a.memory.share();
        let mut b = a.fork_with_memory(memory);
        b.cpu.pc = 0x4100;
        b.signals.io.scheduling.set_affinity(2);
        k.processes.insert(1, a);
        k.processes.insert(2, b);
        let mut io = Completed {
            bytes: bytes.clone(),
            deadline: Instant::now() + Duration::from_secs(3),
        };
        assert!(matches!(
            k.drive(&mut io, u64::MAX),
            Err(RuntimeError::Cancelled)
        ));
        assert_eq!(
            bytes.with_read(8, 8, |b| u64::from_le_bytes(b.try_into().unwrap())),
            17
        );
        assert_eq!(
            k.vm_checkpoint_groups, 0,
            "a pure addition cannot pause same-mm peers"
        );
        assert_eq!(k.vm_local_syscalls, 1);
        assert_eq!(
            k.service_requests, 0,
            "additive mmap runs on the original caller"
        );
        assert_eq!(k.parallel_rounds, 1, "the cohort remains live");
    }

    fn install_filter(k: &mut Kernel<Cpu>, p: &mut Process, action: u32) {
        p.memory
            .write_array(0x1000, [1, 0, 0, 0, 0, 0, 0, 0, 0, 0x11, 0, 0, 0, 0, 0, 0])
            .unwrap();
        let mut instruction = [0u8; 8];
        instruction[..2].copy_from_slice(&6u16.to_le_bytes());
        instruction[4..].copy_from_slice(&action.to_le_bytes());
        p.memory.write_array(0x1100, instruction).unwrap();
        p.linux.vfs.credentials.caps.no_new_privs.set();
        assert_eq!(k.seccomp(p, [1, 0, 0x1000, 0, 0, 0]), Ok(0));
    }
    fn commit_while_peer_runs(relation: u8) {
        commit_with_filter(relation, false);
    }
    fn commit_with_filter(relation: u8, filtered: bool) {
        let mut k = super::super::tests::kernel();
        k.cpu_count = if relation == 0 { 2 } else { 3 };
        k.workers = crate::workers::Pool::new(k.cpu_count);
        k.per_cpu = vec![Duration::ZERO; k.cpu_count];
        let mut a = super::super::tests::process();
        if filtered {
            install_filter(&mut k, &mut a, 0x7fff_0000);
        }
        let (entered, wait) = mpsc::sync_channel(0);
        let (release, receive) = mpsc::sync_channel(0);
        map(
            &mut a,
            0x8000,
            Arc::new(SharedPage::new([0; PAGE_SIZE as usize])),
            Some((entered, receive)),
        );
        code(&mut a, &[0xd4000001, 0x14000000]);
        a.cpu.set_x(0, 0x8000);
        a.cpu.set_x(1, PAGE_SIZE);
        a.cpu.set_x(8, 215);
        let mut paused = Arc::new(SharedPage::new([0; PAGE_SIZE as usize]));
        let mut related = if relation == 2 {
            map(&mut a, 0x1000, paused.clone(), None);
            let memory = a.memory.share();
            let mut b = a.fork_with_memory(memory);
            b.cpu.pc = 0x4100;
            let loop_code: Vec<_> = [0xf9400020u32, 0x91000400, 0xf9000020, 0x17fffffd]
                .into_iter()
                .flat_map(u32::to_le_bytes)
                .collect();
            // Mapping writes happen before any View is published.
            a.memory
                .protect(0x4000, PAGE_SIZE, Permissions::RW)
                .unwrap();
            a.memory.write(0x4100, &loop_code).unwrap();
            a.memory
                .protect(0x4000, PAGE_SIZE, Permissions::RX)
                .unwrap();
            Some(b)
        } else if matches!(relation, 1 | 3 | 4) {
            let mut b = super::super::tests::process();
            map(&mut b, 0x1000, paused.clone(), None);
            if relation >= 3 {
                let fd = if relation == 4 {
                    a.linux.vfs.memfd_create(b"shared-writer", 0).unwrap()
                } else {
                    a.linux
                        .vfs
                        .open_at(-100, b"/shared-library", 0x42, 0o600)
                        .unwrap()
                };
                a.linux.vfs.truncate_fd(fd, PAGE_SIZE).unwrap();
                for memory in [&mut a.memory, &mut b.memory] {
                    memory.unmap(0x6000, PAGE_SIZE).unwrap();
                    let pages = a
                        .linux
                        .vfs
                        .mapping_pages(fd, 0, PAGE_SIZE, relation == 4, relation == 4)
                        .unwrap();
                    if relation == 4 {
                        paused = pages[0].shared_page().unwrap();
                    }
                    memory
                        .map_backed(
                            0x6000,
                            pages,
                            relation == 4,
                            if relation == 4 {
                                Permissions::RW
                            } else {
                                Permissions::RX
                            },
                            false,
                        )
                        .unwrap();
                }
            } else {
                let shared = Arc::new(SharedPage::new([0; PAGE_SIZE as usize]));
                map(&mut a, 0x6000, shared.clone(), None);
                map(&mut b, 0x6000, shared, None);
            }
            code(&mut b, &[0xf9400020, 0x91000400, 0xf9000020, 0x17fffffd]);
            Some(b)
        } else {
            None
        };
        a.signals.io.scheduling.set_affinity(1);
        if let Some(b) = &mut related {
            b.tgid = 2;
            b.vm_id = if relation == 2 { 1 } else { 2 };
            b.signals.io.scheduling.set_affinity(2);
            b.cpu.set_x(1, if relation == 4 { 0x6000 } else { 0x1000 });
        }
        let mut peer = super::super::tests::process();
        let progressing = Arc::new(SharedPage::new([0; PAGE_SIZE as usize]));
        map(&mut peer, 0x1000, progressing.clone(), None);
        code(&mut peer, &[0xf9400020, 0x91000400, 0xf9000020, 0x17fffffd]);
        peer.cpu.set_x(1, 0x1000);
        peer.signals
            .io
            .scheduling
            .set_affinity(1 << (k.cpu_count - 1));
        peer.tgid = 3;
        peer.vm_id = 3;
        k.processes.insert(1, a);
        if let Some(b) = related {
            k.processes.insert(2, b);
        }
        k.processes.insert(3, peer);
        let stopped = Arc::new(AtomicBool::new(false));
        let done = stopped.clone();
        let observer = std::thread::spawn(move || {
            wait.recv_timeout(Duration::from_secs(3)).unwrap();
            let before = count(&progressing);
            let other_before = count(&paused);
            // This is a progress/quiescence assertion, not a 100 ms latency SLA.
            let deadline = Instant::now() + Duration::from_secs(5);
            while (count(&progressing) == before || relation >= 3 && count(&paused) == other_before)
                && Instant::now() < deadline
            {
                std::thread::yield_now();
            }
            let advanced = count(&progressing) > before;
            let quiescent = count(&paused) == other_before;
            done.store(true, Ordering::Relaxed);
            release.send(()).unwrap();
            (advanced, quiescent)
        });
        assert!(matches!(
            k.drive(&mut Stop(stopped), u64::MAX),
            Err(RuntimeError::Cancelled)
        ));
        let (advanced, quiescent) = observer.join().unwrap();
        assert!(
            advanced,
            "an unrelated VM stopped during the mapping commit"
        );
        assert_eq!(
            quiescent,
            relation < 3,
            "only same-mm or coupled-provider peers must stop during a local mapping commit"
        );
        assert_eq!(k.vm_checkpoint_groups, 1);
        assert_eq!(k.vm_checkpoint_spaces, if relation == 1 { 2 } else { 1 });
        assert_eq!(k.vm_local_syscalls, 1);
        assert_eq!(k.parallel_rounds, 1);
        if filtered {
            assert_eq!(k.processes.read(&1).seccomp.evaluations(), 1);
        }
        assert!(!k
            .processes
            .read(&1)
            .memory
            .regions()
            .iter()
            .any(|(a, b, _)| *a <= 0x8000 && *b > 0x8000));
    }
    #[test]
    fn allowed_filtered_mapping_keeps_an_unrelated_cpu_running() {
        commit_with_filter(0, true);
    }
    #[test]
    fn allowed_filtered_mapping_quiesces_only_its_clone_vm_peers() {
        commit_with_filter(2, true);
    }
    #[test]
    fn denied_filtered_mapping_preserves_memory_and_applies_its_decision_once() {
        let mut k = super::super::tests::kernel();
        k.cpu_count = 2;
        k.workers = crate::workers::Pool::new(2);
        k.per_cpu = vec![Duration::ZERO; 2];
        let mut a = super::super::tests::process();
        install_filter(&mut k, &mut a, 0x0005_000d); // ERRNO(EACCES)
        code(&mut a, &[0xd4000001, 0x14000000]);
        a.cpu.set_x(0, 0x8000);
        a.cpu.set_x(1, PAGE_SIZE);
        a.cpu.set_x(8, 215);
        let mut b = super::super::tests::process();
        code(&mut b, &[0x14000000]);
        b.tgid = 2;
        b.vm_id = 2;
        b.signals.io.scheduling.set_affinity(2);
        k.processes.insert(1, a);
        k.processes.insert(2, b);
        assert!(k
            .parallel_round(&mut trames_linux::CapturedOutput::default(), u64::MAX)
            .unwrap());
        let p = &k.processes.read(&1);
        assert_eq!(p.cpu.x(0), error(Errno(13)));
        assert!(p.memory.read_array::<1>(0x8000).is_ok());
        assert_eq!(p.seccomp.evaluations(), 1);
        assert!(p.seccomp_entry.is_none());
        assert_eq!(k.vm_local_syscalls, 0);
    }
    #[test]
    fn vm_commit_keeps_an_unrelated_cpu_running_while_the_owner_blocks() {
        commit_while_peer_runs(0);
    }
    #[test]
    fn vm_commit_quiesces_shared_backings_but_keeps_an_unrelated_vm_running() {
        commit_while_peer_runs(1);
    }
    #[test]
    fn vm_commit_keeps_a_shared_readonly_library_peer_running() {
        commit_while_peer_runs(3);
    }
    #[test]
    fn vm_commit_keeps_a_canonical_shared_file_writer_running() {
        commit_while_peer_runs(4);
    }
    #[test]
    fn vm_commit_quiesces_all_clone_vm_cpus_and_keeps_an_unrelated_vm_running() {
        commit_while_peer_runs(2);
    }
    #[test]
    fn persistent_checks_keep_jobs_and_translations_until_actual_cancellation() {
        struct Polls(u64);
        impl GuestOutput for Polls {
            // Explicit observation clock for this white-box fixture only.
            fn host_interest(&mut self, wait: &mut trames_linux::HostWait) -> std::io::Result<()> {
                wait.until(Instant::now() + Duration::from_millis(1));
                Ok(())
            }

            fn source_console(&mut self) -> std::sync::Arc<dyn trames_vfs::ConsoleIo> {
                std::sync::Arc::new(trames_vfs::CapturedConsole::default())
            }

            fn poll_host(
                &mut self,
                _: &trames_vfs::Vfs,
            ) -> std::io::Result<trames_linux::HostState> {
                self.0 += 1;
                Ok(trames_linux::HostState::from_cancelled(self.0 == 5))
            }

            fn write(&mut self, _: OutputFd, bytes: &[u8]) -> std::io::Result<usize> {
                Ok(bytes.len())
            }
        }
        let mut k = super::super::tests::kernel();
        k.cpu_count = 2;
        k.workers = crate::workers::Pool::new(2);
        k.per_cpu = vec![Duration::ZERO; 2];
        for id in 1..=2 {
            let mut p = super::super::tests::process();
            p.tgid = id;
            p.vm_id = id as u64;
            p.signals.io.scheduling.set_affinity(1 << (id - 1));
            code(&mut p, &[0x14000000]);
            k.processes.insert(id, p);
        }
        let mut polls = Polls(0);
        assert!(matches!(
            k.drive(&mut polls, u64::MAX),
            Err(RuntimeError::Cancelled)
        ));
        assert_eq!(polls.0, 5);
        assert_eq!(k.persistent_control_checks, 4);
        assert_eq!(k.parallel_rounds, 1);
        assert_eq!(k.vm_checkpoint_groups, 0);
        assert_eq!(k.parallel_memory.metrics.full_rebuilds, 2);
        assert!(k
            .processes
            .values()
            .all(|p| p.memory.parallel_views_quiescent()));
        let limit = k.instructions + 1000;
        assert!(matches!(
            k.drive(&mut trames_linux::CapturedOutput::default(), limit),
            Err(RuntimeError::BudgetExceeded(_))
        ));
        assert_eq!(k.instructions, limit);
    }
    #[test]
    fn host_pause_resume_keeps_original_cpus_views_and_one_cohort() {
        struct Pauses {
            pages: Vec<Arc<SharedPage>>,
            epoch: Arc<std::sync::OnceLock<std::sync::Weak<crate::run_queue::Epoch<Cpu>>>>,
            previous: Vec<u64>,
            stable: usize,
            since: Instant,
            deadline: Instant,
            paused: bool,
            cycles: usize,
            cancel: bool,
        }
        impl GuestOutput for Pauses {
            fn source_console(&mut self) -> Arc<dyn trames_vfs::ConsoleIo> {
                Arc::new(trames_vfs::CapturedConsole::default())
            }
            fn paused(&self) -> bool {
                self.paused
            }
            fn host_interest(&mut self, wait: &mut trames_linux::HostWait) -> std::io::Result<()> {
                wait.until(std::time::Instant::now() + Duration::from_millis(1));
                Ok(())
            }
            fn poll_host(
                &mut self,
                _: &trames_vfs::Vfs,
            ) -> std::io::Result<trames_linux::HostState> {
                assert!(
                    Instant::now() < self.deadline,
                    "pause/resume failed to progress"
                );
                if self.paused {
                    let epoch = self.epoch.get().unwrap().upgrade().unwrap();
                    // Equal samples do not acknowledge a pause: an in-flight
                    // CPU may be descheduled between them. Observe the queue
                    // after every execution/completion lease has returned,
                    // then read counters and require them to remain unchanged.
                    if !epoch.host_pause_settled_for_test() {
                        assert_eq!(self.stable, 0, "settled host pause became active");
                        return Ok(trames_linux::HostState::Running);
                    }
                    let current: Vec<_> = self.pages.iter().map(|p| count(p)).collect();
                    if self.stable == 0 {
                        self.previous = current;
                        self.since = Instant::now();
                    } else {
                        assert_eq!(
                            current, self.previous,
                            "guest executed after host pause settled"
                        );
                    }
                    self.stable += 1;
                    if self.stable >= 3 && self.since.elapsed() >= Duration::from_millis(20) {
                        self.paused = false;
                        self.stable = 0;
                        self.cycles += 1;
                    }
                } else {
                    let current: Vec<_> = self.pages.iter().map(|p| count(p)).collect();
                    if current
                        .iter()
                        .zip(&self.previous)
                        .all(|(now, before)| now > before)
                    {
                        if self.cycles == 3 {
                            self.cancel = true;
                            return Ok(trames_linux::HostState::Cancelled);
                        }
                        self.previous = current;
                        self.paused = true;
                        self.since = Instant::now();
                    }
                }
                Ok(trames_linux::HostState::Running)
            }

            fn write(&mut self, _: OutputFd, bytes: &[u8]) -> std::io::Result<usize> {
                Ok(bytes.len())
            }
        }
        for (cpus, slots) in [(4, 4), (12, 12), (4, 1)] {
            let mut k = super::super::tests::kernel();
            k.cpu_count = cpus;
            k.workers = crate::workers::Pool::new(slots);
            k.per_cpu = vec![Duration::ZERO; cpus];
            let epoch = Arc::new(std::sync::OnceLock::new());
            k.execution_epoch_for_test = Some(epoch.clone());
            let mut pages = Vec::new();
            for id in 1..=cpus {
                let mut p = super::super::tests::process();
                p.tgid = id as u32;
                p.vm_id = id as u64;
                p.signals
                    .io
                    .scheduling
                    .set_affinity(if slots == 1 { 1 } else { 1 << (id - 1) });
                let page = Arc::new(SharedPage::new([0; PAGE_SIZE as usize]));
                map(&mut p, 0x3000, page.clone(), None);
                p.cpu.set_x(0, 0x3000);
                p.cpu.set_x(1, 0);
                code(&mut p, &[0x91000421, 0xf9000001, 0x17fffffe]);
                k.processes.insert(id as u32, p);
                pages.push(page);
            }
            let mut host = Pauses {
                pages,
                epoch,
                previous: vec![0; cpus],
                stable: 0,
                since: Instant::now(),
                deadline: Instant::now() + Duration::from_secs(5),
                paused: false,
                cycles: 0,
                cancel: false,
            };
            assert!(matches!(
                k.drive(&mut host, u64::MAX),
                Err(RuntimeError::Cancelled)
            ));
            assert_eq!(host.cycles, 3);
            assert_eq!(k.parallel_rounds, 1);
            assert_eq!(k.parallel_memory.metrics.full_rebuilds, cpus as u64);
            assert!(k.cohort_return_syscalls.is_empty());
            assert_eq!(k.service_requests, 0);
            assert_eq!(k.serviced_syscalls, 0);
            assert!(k
                .processes
                .values()
                .all(|p| p.memory.parallel_views_quiescent()));
        }
    }
    #[test]
    fn cohort_return_profile_excludes_local_calls_and_disabled_profiling() {
        for (profile, number, returned, trace) in [
            (false, 0xff00, false, false),
            (true, 172, false, false),
            (true, 0xff00, false, false),
            (true, 283, false, false),
            (true, 278, false, false),
            (true, 278, false, true),
            (true, 179, false, false),
            (true, 179, false, true),
            (true, 0xff00, false, true),
        ] {
            let mut k = super::super::tests::kernel();
            k.cpu_count = 2;
            k.workers = crate::workers::Pool::new(2);
            k.per_cpu = vec![Duration::ZERO; 2];
            k.profile_syscalls = profile;
            for id in 1..=2 {
                let mut p = super::super::tests::process();
                p.tgid = id;
                p.linux.trace = trace;
                p.vm_id = id as u64;
                p.signals.io.scheduling.set_affinity(1 << (id - 1));
                code(&mut p, &[0xd4000001, 0x17ffffff]);
                p.cpu.set_x(8, number);
                k.processes.insert(id, p);
            }
            assert!(k
                .parallel_round(&mut trames_linux::CapturedOutput::default(), 1000)
                .unwrap());
            assert_eq!(
                k.cohort_return_syscalls.contains_key(&(number as u32)),
                returned
            );
            assert!(k.cohort_return_native.is_empty());
        }
    }
    #[test]
    fn native_device_open_and_bridge_read_keep_four_and_twelve_cpu_cohorts() {
        struct Host {
            broker: trames_bridge::Broker,
            checks: usize,
            sent: bool,
            done: Arc<SharedPage>,
            deadline: Instant,
        }
        impl GuestOutput for Host {
            fn source_console(&mut self) -> Arc<dyn trames_vfs::ConsoleIo> {
                Arc::new(trames_vfs::CapturedConsole::default())
            }
            fn poll_host(
                &mut self,
                _: &trames_vfs::Vfs,
            ) -> std::io::Result<trames_linux::HostState> {
                self.checks += 1;
                if self.checks >= 3 && !self.sent {
                    if let Some(bytes) = self.broker.poll(32768).unwrap() {
                        let request: trames_bridge::HostRequest =
                            serde_json::from_slice(&bytes).unwrap();
                        self.broker.reply(&serde_json::to_vec(&serde_json::json!({"version":1,"ticket":request.ticket,"result":{"ready":true}})).unwrap()).unwrap();
                        self.sent = true;
                    }
                }
                Ok(trames_linux::HostState::from_cancelled(
                    count(&self.done) != 0 || Instant::now() >= self.deadline,
                ))
            }

            fn host_interest(&mut self, wait: &mut trames_linux::HostWait) -> std::io::Result<()> {
                wait.until(std::time::Instant::now() + Duration::from_millis(1));
                Ok(())
            }
            fn write(&mut self, _: OutputFd, bytes: &[u8]) -> std::io::Result<usize> {
                Ok(bytes.len())
            }
        }
        for (cpus, slots) in [(4, 4), (12, 12), (4, 1)] {
            let mut k = super::super::tests::kernel();
            k.cpu_count = cpus;
            k.workers = crate::workers::Pool::new(slots);
            k.per_cpu = vec![Duration::ZERO; cpus];
            let done = Arc::new(SharedPage::new([0; PAGE_SIZE as usize]));
            let broker = trames_bridge::Broker::default();
            let frame = b"{\"version\":1,\"id\":7,\"method\":\"device.info\",\"params\":{}}\n";
            for id in 1..=cpus {
                let mut p = super::super::tests::process();
                p.tgid = id as u32;
                p.vm_id = id as u64;
                p.signals
                    .io
                    .scheduling
                    .set_affinity(if slots == 1 { 1 } else { 1 << (id - 1) });
                if id == 1 {
                    p.linux.vfs.set_runtime_info(1, Default::default());
                    p.linux.vfs.attach_bridge(broker.clone());
                    p.memory.write(0x1000, b"/dev/trames/info\0").unwrap();
                    p.memory.write(0x1100, frame).unwrap();
                    map(&mut p, 0x3000, done.clone(), None);
                    for (i, value) in [(-100i64) as u64, 0x1000, 2, 0].into_iter().enumerate() {
                        p.cpu.set_x(i, value);
                    }
                    code(
                        &mut p,
                        &[
                            0xd2800708,
                            0xd4000001,
                            0xaa0003f4,
                            0xd2822001,
                            0xd2800002 | ((frame.len() as u32) << 5),
                            0xd2800808,
                            0xd4000001,
                            0xaa1403e0,
                            0xd2840001,
                            0xd2808002,
                            0xd28007e8,
                            0xd4000001,
                            0xd2860001,
                            0xf9000020,
                            0x14000000,
                        ],
                    );
                } else {
                    code(&mut p, &[0x14000000]);
                }
                k.processes.insert(id as u32, p);
            }
            let mut host = Host {
                broker,
                checks: 0,
                sent: false,
                done: done.clone(),
                deadline: Instant::now() + Duration::from_secs(5),
            };
            assert!(matches!(
                k.drive(&mut host, u64::MAX),
                Err(RuntimeError::Cancelled)
            ));
            assert!(host.sent);
            assert!(count(&done) > 0 && count(&done) < 1024);
            assert_eq!(k.parallel_rounds, 1);
            assert!(k.cohort_return_syscalls.is_empty());
            assert_eq!(k.service_requests, 0);
            assert_eq!(k.serviced_syscalls, 0);
        }
    }
    fn native_bridge_retains_cohort(idle_peer: bool, start_parked: bool) {
        struct Roundtrip {
            checks: usize,
            sender: trames_vfs::DirectFd,
            completed: Arc<SharedPage>,
            deadline: Instant,
            finished: bool,
        }
        impl GuestOutput for Roundtrip {
            // Explicit observation clock for this white-box fixture only.
            fn host_interest(&mut self, wait: &mut trames_linux::HostWait) -> std::io::Result<()> {
                wait.until(Instant::now() + Duration::from_millis(1));
                Ok(())
            }

            fn source_console(&mut self) -> std::sync::Arc<dyn trames_vfs::ConsoleIo> {
                std::sync::Arc::new(trames_vfs::CapturedConsole::default())
            }

            fn poll_host(
                &mut self,
                _: &trames_vfs::Vfs,
            ) -> std::io::Result<trames_linux::HostState> {
                self.checks += 1;
                if self.checks == 3 {
                    // wl_display.sync(new_id=2), sent after workers have parked.
                    let request = [1u32, 12u32 << 16, 2u32]
                        .into_iter()
                        .flat_map(u32::to_ne_bytes)
                        .collect::<Vec<_>>();
                    assert_eq!(self.sender.write(&request), Ok(12));
                }
                self.finished = self.checks >= 8 && count(&self.completed) == 24
                    || Instant::now() >= self.deadline;
                Ok(trames_linux::HostState::from_cancelled(self.finished))
            }

            fn write(&mut self, _: OutputFd, bytes: &[u8]) -> std::io::Result<usize> {
                Ok(bytes.len())
            }
        }
        let mut k = super::super::tests::kernel();
        k.cpu_count = 2;
        k.workers = crate::workers::Pool::new(2);
        k.per_cpu = vec![Duration::ZERO; 2];
        let mut a = super::super::tests::process();
        let _server = a.linux.vfs.enable_wayland(b"/run/user/0").unwrap();
        let fd = a.linux.vfs.local_create(1, 0).unwrap();
        let socket = a.linux.vfs.local_socket(fd).unwrap().unwrap();
        a.linux
            .vfs
            .local_connect(&socket, b"\x01\x00/run/user/0/wayland-0\0")
            .unwrap();
        a.linux.vfs.dispatch_native_events();
        assert!(a.linux.vfs.has_native_services());
        let sender = a.linux.vfs.direct_descriptors().get(fd).unwrap();
        let completed = Arc::new(SharedPage::new([0; PAGE_SIZE as usize]));
        map(&mut a, 0x2000, completed.clone(), None);
        code(&mut a, &[0xd4000001, 0xf9000120, 0x14000000]); // read, save result, spin
        a.cpu.set_x(9, 0x2000);
        a.cpu.set_x(8, 63);
        put_args(&mut a.cpu, [fd as u64, 0x1000, 24, 0, 0, 0]);
        let mut b = a.fork();
        b.tgid = 2;
        b.vm_id = 2;
        b.signals.io.scheduling.set_affinity(2);
        let progress = Arc::new(SharedPage::new([0; PAGE_SIZE as usize]));
        map(&mut b, 0x2000, progress.clone(), None);
        b.cpu.set_x(1, 0x2000);
        b.memory
            .protect(0x4000, PAGE_SIZE, Permissions::RW)
            .unwrap();
        code(&mut b, &[0xf9400020, 0x91000400, 0xf9000020, 0x17fffffd]);
        if idle_peer {
            // No runnable CPU: retain the native source until its response wakes a.
            let [reader, _writer] = b.linux.vfs.pipe(0).unwrap();
            b.memory
                .protect(0x4000, PAGE_SIZE, Permissions::RW)
                .unwrap();
            code(&mut b, &[0xd4000001, 0x14000000]);
            b.cpu.set_x(8, 63);
            put_args(&mut b.cpu, [reader as u64, 0x1000, 1, 0, 0, 0]);
        }
        let mut io = Roundtrip {
            checks: 0,
            sender,
            completed: completed.clone(),
            deadline: Instant::now() + Duration::from_secs(3),
            finished: false,
        };
        if start_parked {
            for (id, p) in [(1, &mut a), (2, &mut b)] {
                let arguments = args(&p.cpu);
                p.cpu.pc += 4; // as if the read SVC has already retired
                k.call(id, p, 63, arguments, &mut io);
                assert!(matches!(p.state, State::Blocked(63, _)));
            }
        }
        k.processes.insert(1, a);
        k.processes.insert(2, b);
        assert!(matches!(
            k.drive(&mut io, u64::MAX),
            Err(RuntimeError::Cancelled)
        ));
        assert_eq!(count(&completed), 24);
        assert_eq!(k.service_requests, 0);
        assert_eq!(
            k.processes.read(&1).memory.read_array::<4>(0x1000).unwrap(),
            2u32.to_ne_bytes()
        );
        assert_eq!(k.parallel_rounds, 1);
        assert_eq!(k.vm_checkpoint_groups, 0);
        if !idle_peer {
            assert!(count(&progress) > 0);
        }
    }
    #[test]
    fn native_wayland_roundtrip_keeps_an_unrelated_cpu_running() {
        native_bridge_retains_cohort(false, false);
    }
    #[test]
    fn native_wayland_response_wakes_an_idle_cohort_without_rebuilding() {
        native_bridge_retains_cohort(true, false);
    }
    #[test]
    fn native_wayland_admits_an_already_idle_cohort() {
        native_bridge_retains_cohort(true, true);
    }
    #[test]
    fn persistent_idle_waits_survive_fd_reuse_and_wake_without_rebuilding_the_cohort() {
        struct Input {
            checks: u64,
            pause: bool,
            paused: bool,
            writer: trames_vfs::DirectFd,
            completed: Arc<SharedPage>,
            deadline: Instant,
        }
        impl GuestOutput for Input {
            fn paused(&self) -> bool {
                self.paused
            }
            fn host_interest(&mut self, wait: &mut trames_linux::HostWait) -> std::io::Result<()> {
                wait.until(std::time::Instant::now() + Duration::from_millis(1));
                Ok(())
            }
            fn waits_for_host(&self) -> bool {
                true
            }
            fn source_console(&mut self) -> Arc<dyn trames_vfs::ConsoleIo> {
                Arc::new(
                    trames_vfs::ConsoleCallbacks::new(
                        |_| Ok(Vec::new()),
                        |_, bytes| Ok(bytes.len()),
                        |stream, events| {
                            (
                                events
                                    & if stream == trames_vfs::ConsoleStream::Input {
                                        0
                                    } else {
                                        4
                                    },
                                [0; 2],
                            )
                        },
                    )
                    .readiness(Arc::default()),
                )
            }

            fn poll_host(
                &mut self,
                _: &trames_vfs::Vfs,
            ) -> std::io::Result<trames_linux::HostState> {
                self.checks += 1;
                if self.pause && self.checks == 2 {
                    self.paused = true;
                }
                if self.checks == 4 {
                    assert_eq!(self.writer.write(b"xy"), Ok(2));
                }
                if self.pause && (4..=8).contains(&self.checks) {
                    assert!(
                        self.completed
                            .with_read(0, 16, |bytes| bytes.iter().all(|b| *b == 0)),
                        "paused readers must retain their accepted results"
                    );
                }
                if self.checks == 8 {
                    self.paused = false;
                }
                let completed = self.completed.with_read(0, 16, |bytes| {
                    bytes[..8] == 1u64.to_le_bytes() && bytes[8..] == 1u64.to_le_bytes()
                });
                Ok(trames_linux::HostState::from_cancelled(
                    self.checks >= 12 && completed || Instant::now() >= self.deadline,
                ))
            }
            fn stdin_ready(&mut self) -> std::io::Result<bool> {
                Ok(false)
            }

            fn write(&mut self, _: OutputFd, bytes: &[u8]) -> std::io::Result<usize> {
                Ok(bytes.len())
            }
        }
        for pause in [false, true] {
            let mut k = super::super::tests::kernel();
            k.cpu_count = 2;
            k.workers = crate::workers::Pool::new(2);
            k.per_cpu = vec![Duration::ZERO; 2];
            let mut a = super::super::tests::process();
            code(&mut a, &[0xf9000120, 0x14000000]); // acknowledge the resumed read, then loop
            let [reader, writer] = a.linux.vfs.pipe(0).unwrap();
            let writer = a.linux.vfs.direct_descriptors().get(writer).unwrap();
            let mut b = a.fork();
            b.tgid = 2;
            b.vm_id = 2;
            b.signals.io.scheduling.set_affinity(2);
            let completed = Arc::new(SharedPage::new([0; PAGE_SIZE as usize]));
            let mut io = Input {
                checks: 0,
                pause,
                paused: false,
                writer,
                completed: completed.clone(),
                deadline: Instant::now() + Duration::from_secs(3),
            };
            let mut results = Vec::new();
            for (id, mut p) in [(1, a), (2, b)] {
                let result = Arc::new(SharedPage::new([0; PAGE_SIZE as usize]));
                p.memory.unmap(0x1000, PAGE_SIZE).unwrap();
                map(&mut p, 0x1000, result.clone(), None);
                results.push(result);
                map(&mut p, 0x2000, completed.clone(), None);
                p.cpu.set_x(9, 0x2000 + (id as u64 - 1) * 8);
                k.call(id, &mut p, 63, [reader as u64, 0x1000, 1, 0, 0, 0], &mut io);
                assert!(p.byte_wait.is_some());
                p.linux.vfs.close(reader).unwrap();
                assert_eq!(p.linux.vfs.eventfd(9, O_NONBLOCK).unwrap(), reader);
                k.processes.insert(id, p);
            }
            assert!(matches!(
                k.drive(&mut io, u64::MAX),
                Err(RuntimeError::Cancelled)
            ));
            let mut bytes: Vec<_> = results
                .iter()
                .map(|p| p.with_read(0, 1, |b| b[0]))
                .collect();
            bytes.sort_unstable();
            assert_eq!(bytes, b"xy");
            assert_eq!(k.parallel_rounds, 1);
            assert_eq!(k.worker_direct_syscalls, 2);
            assert_eq!(k.service_requests, 0);
            for (id, mut p) in k.processes.iter_mut() {
                assert!(p.retained_byte.is_none());
                if id == 1 {
                    assert_eq!(p.linux.vfs.read(reader, 8).unwrap(), 9u64.to_le_bytes());
                } else {
                    assert_eq!(p.linux.vfs.fd_kind(reader), Err(Errno(9)));
                }
            }
        }
    }
}

#[cfg(all(test, trames_interpreter_conformance))]
mod creation_tests {
    use super::*;
    use std::sync::mpsc;
    struct Wake(mpsc::Sender<()>);
    impl trames_vfs::IoWake for Wake {
        fn wake_io(&self, _: &Arc<trames_vfs::IoSignal>) {
            let _ = self.0.send(());
        }
    }
    #[test]
    fn task_birth_and_wait_finish_without_stopping_a_foreign_cpu() {
        for mode in 0..10 {
            let (publish, handles) = mpsc::channel();
            let (start, go) = mpsc::channel();
            let (finished, done) = mpsc::channel();
            let worker = std::thread::spawn(move || {
                let mut k = super::super::tests::kernel();
                k.cpu_count = 3;
                k.workers = crate::workers::Pool::new(3);
                k.per_cpu = vec![Duration::ZERO; 3];
                k.profile_syscalls = true;
                let mut root = super::super::tests::process();
                root.signals.io.scheduling.set_affinity(7);
                let [reader, writer] = root.linux.vfs.pipe(0).unwrap();
                let [resume, _] = root.linux.vfs.pipe(0).unwrap();
                let observed = root
                    .linux
                    .vfs
                    .shared_files()
                    .lookup(reader)
                    .unwrap()
                    .unwrap()
                    .direct_byte()
                    .unwrap();
                root.memory.write(0x1100, b"P").unwrap();
                let mov = |reg: u32, value: u32| 0xd2800000 | (value & 0xffff) << 5 | reg;
                let flags: u64 = match mode {
                    0 => 17,
                    1 => 0x111,
                    2 => 0x4111,
                    3 => 0x310b00,
                    4 => trames_vfs::CLONE_NEWPID | 17,
                    5 => {
                        trames_vfs::CLONE_NEWPID
                            | trames_vfs::CLONE_NEWNS
                            | trames_vfs::CLONE_NEWUTS
                            | trames_vfs::CLONE_NEWIPC
                            | trames_vfs::CLONE_NEWNET
                            | trames_vfs::CLONE_NEWCGROUP
                            | 17
                    }
                    6 => 0x100011,
                    7 => 0x1000011,
                    8 => 0x200011,
                    _ => 17,
                };
                let mut code = vec![
                    mov(0, flags as u32),
                    0xf2a00000 | ((flags >> 16) as u32) << 5,
                    mov(1, 0),
                    mov(2, if mode == 3 { 0x1300 } else { 0 }),
                    mov(3, 0),
                    mov(4, if mode == 3 { 0x1300 } else { 0 }),
                    mov(8, 220),
                    0xd4000001,
                    // cbnz x0,+16: parent skips the child's exit path.
                    0xb5000080,
                    mov(0, 27),
                    mov(8, 93),
                    0xd4000001,
                ];
                if mode == 3 {
                    code.extend([
                        mov(0, 0x1300),
                        mov(1, 0),
                        mov(2, 3),
                        mov(3, 0),
                        mov(4, 0),
                        mov(5, 0),
                        mov(8, 98),
                        0xd4000001,
                    ]);
                } else {
                    code.extend([
                        mov(1, 0x1200),
                        mov(2, 0),
                        mov(3, 0),
                        mov(4, 0),
                        mov(8, 260),
                        0xd4000001,
                    ]);
                }
                code.extend([
                    mov(0, writer),
                    mov(1, 0x1100),
                    mov(2, 1),
                    mov(8, 64),
                    0xd4000001,
                    mov(0, resume),
                    mov(1, 0x1500),
                    mov(2, 1),
                    mov(8, 63),
                    0xd4000001,
                    0x14000000,
                ]);
                for (i, word) in code.into_iter().enumerate() {
                    root.memory
                        .write_array(0x4000 + i as u64 * 4, word.to_le_bytes())
                        .unwrap();
                }
                root.memory
                    .write_array(0x4300, 0x14000000u32.to_le_bytes())
                    .unwrap();
                root.memory
                    .protect(
                        0x4000,
                        trames_memory::PAGE_SIZE,
                        trames_memory::Permissions::RX,
                    )
                    .unwrap();
                let mut output = trames_linux::CapturedOutput::default();
                k.syscall(1, &mut root, 220, [17, 0, 0, 0, 0, 0], &mut output)
                    .unwrap();
                k.processes.get_mut(&2).unwrap().cpu.set_pc(0x4300);
                root.cpu.set_pc(0x4000);
                let task = root.signals.io.clone();
                let borrow = if mode == 9 {
                    Some(root.memory.parallel_view(&mut k.parallel_memory).unwrap())
                } else {
                    None
                };
                k.processes.insert(1, root);
                publish.send((observed, task, borrow)).unwrap();
                go.recv().unwrap();
                let result = k.parallel_epoch(&mut output, u64::MAX / 2, true);
                let value = if mode == 3 {
                    k.processes.read(&1).memory.read_u64(0x1300).unwrap() as u32
                } else {
                    k.processes.read(&1).memory.read_u64(0x1200).unwrap() as u32
                };
                finished
                    .send((
                        result.is_ok(),
                        value,
                        k.cohort_return_syscalls.get(&220).copied().unwrap_or(0),
                        k.parallel_rounds,
                    ))
                    .unwrap();
            });
            let (observed, task, borrow) = handles.recv_timeout(Duration::from_secs(5)).unwrap();
            let (wake, readable) = mpsc::channel();
            let target: Arc<dyn trames_vfs::IoWake> = Arc::new(Wake(wake));
            let signal = trames_vfs::IoSignal::new(0, Arc::downgrade(&target));
            let _subscription = observed.subscribe(&signal);
            start.send(()).unwrap();
            let notified = readable.recv_timeout(Duration::from_secs(1));
            let bytes = observed.read(1);
            let early = done.try_recv().ok();
            let live = early.is_none();
            drop(borrow);
            let _ = task.job_signal(9, false, Info::default(), true);
            let result = early
                .map(Ok)
                .unwrap_or_else(|| done.recv_timeout(Duration::from_secs(5)));
            worker.join().unwrap();
            assert!(
                notified.is_ok() && bytes == Ok(b"P".to_vec()) && live,
                "mode={mode}: birth stopped foreign CPU: {bytes:?} {result:?}"
            );
            let expected = if mode == 3 { 0 } else { 27 << 8 };
            assert!(
                matches!(result,Ok((true,value,0,1)) if value==expected),
                "mode={mode}: {result:?}"
            );
        }
    }
}
