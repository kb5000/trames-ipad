from pathlib import Path
import json,subprocess,gzip,time,hashlib
io=Path('/mnt/trames-output');rows=[json.loads(x) for x in (io/'ipad-ci-v3-build.jsonl').read_text().splitlines() if x.startswith('{')];b=next(r['executable'] for r in reversed(rows) if r.get('executable') and r.get('target',{}).get('name')=='kernel-conformance');q='/home/main.guest/trames-ci/target/qemu-oracle/bin/qemu-aarch64'
start=time.monotonic();results=[];tail=[]
with gzip.open(io/'ipad-ci-v3-full-qemu.log.gz','wb') as z:
 p=subprocess.Popen(['timeout','300',q,'-cpu','max',b],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,cwd='/home/main.guest/trames-ipad-ci-20261126')
 for line in p.stdout:
  z.write(line);s=line.decode(errors='replace');tail.append(s)
  if len(tail)>170:tail.pop(0)
  if s.startswith('test '):z.flush()
  if ' ... FAILED' in s or 'test result:' in s:results.append(s.strip())
 code=p.wait()
result=dict(code=code,seconds=time.monotonic()-start,results=results,binary_sha256=hashlib.sha256(Path(b).read_bytes()).hexdigest(),source_manifest_sha256=hashlib.sha256((io/'ipad-ci-20261126-source.json').read_bytes()).hexdigest(),qemu_version=subprocess.check_output([q,'--version'],text=True).splitlines()[0])
(io/'ipad-ci-v3-full-qemu.json').write_text(json.dumps(result,indent=2)+'\n');(io/'ipad-ci-v3-full-qemu-tail.log').write_text(''.join(tail));print(json.dumps(result),flush=True)
