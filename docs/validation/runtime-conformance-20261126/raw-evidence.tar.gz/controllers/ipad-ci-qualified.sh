#!/usr/bin/env bash
set -euo pipefail
export PATH=/home/main.guest/.cargo/bin:$PATH
export CARGO_TARGET_DIR=/home/main.guest/trames-ci/target
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_TARGET_AARCH64_UNKNOWN_LINUX_MUSL_LINKER=aarch64-linux-gnu-gcc
src=/home/main.guest/trames-ipad-ci-20261126
io=/mnt/trames-output
python3 - <<'PY'
from pathlib import Path
import shutil,json,hashlib
src=Path('/mnt/trames-output/ipad-ci-20261126-source');dst=Path('/home/main.guest/trames-ipad-ci-20261126')
assert not dst.exists()
shutil.copytree(src,dst,symlinks=True)
manifest=json.loads(Path('/mnt/trames-output/ipad-ci-20261126-source.json').read_text())
for n,h in manifest['files'].items():assert hashlib.sha256((dst/n).read_bytes()).hexdigest()==h,n
(dst/'runtime/target').mkdir(exist_ok=True)
(dst/'runtime/target/guest-cli').symlink_to('/home/main.guest/trames-linux-wsi-qualified/runtime/target/guest-cli',target_is_directory=True)
print('Verified source snapshot',manifest['commits'],flush=True)
PY
cd "$src"
cargo test -p trames-core --test kernel-conformance --target aarch64-unknown-linux-musl --locked --offline --no-run --message-format=json > "$io/ipad-ci-qualified-build.jsonl" 2> "$io/ipad-ci-qualified-build.log"
python3 - <<'PY'
from pathlib import Path
import json,subprocess,gzip,time,hashlib
io=Path('/mnt/trames-output')
rows=[json.loads(x) for x in (io/'ipad-ci-qualified-build.jsonl').read_text().splitlines() if x.startswith('{')]
binary=next(r['executable'] for r in reversed(rows) if r.get('executable') and r.get('target',{}).get('name')=='kernel-conformance')
qemu='/home/main.guest/trames-ci/target/qemu-oracle/bin/qemu-aarch64'
receipt=dict(binary=binary,binary_sha256=hashlib.sha256(Path(binary).read_bytes()).hexdigest(),source_manifest_sha256=hashlib.sha256((io/'ipad-ci-20261126-source.json').read_bytes()).hexdigest(),qemu_version=subprocess.check_output([qemu,'--version'],text=True).splitlines()[0],profile_debug=0,target='aarch64-unknown-linux-musl')
(io/'ipad-ci-qualified-build.json').write_text(json.dumps(receipt,indent=2)+'\n')
for lane,command in [('qemu',[qemu,'-cpu','max',binary]),('native',[binary])]:
 start=time.monotonic();tail=[];fails=[]
 with gzip.open(io/('ipad-ci-qualified-'+lane+'.log.gz'),'wb') as log:
  process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  for line in process.stdout:
   log.write(line);text=line.decode(errors='replace');tail.append(text)
   if len(tail)>160:tail.pop(0)
   if ' ... FAILED' in text or 'test result:' in text:fails.append(text.strip())
 code=process.wait()
 result=dict(lane=lane,code=code,seconds=time.monotonic()-start,results=fails,build=receipt)
 (io/('ipad-ci-qualified-'+lane+'.json')).write_text(json.dumps(result,indent=2)+'\n')
 (io/('ipad-ci-qualified-'+lane+'-tail.log')).write_text(''.join(tail))
 print(json.dumps(result),flush=True)
PY
