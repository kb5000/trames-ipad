from pathlib import Path
import json,subprocess,gzip,time,hashlib
io=Path('/mnt/trames-output');rows=[json.loads(x) for x in (io/'ipad-ci-v3-build.jsonl').read_text().splitlines() if x.startswith('{')]
b=next(r['executable'] for r in reversed(rows) if r.get('executable') and r.get('target',{}).get('name')=='kernel-conformance');q='/home/main.guest/trames-ci/target/qemu-oracle/bin/qemu-aarch64'
receipt=dict(binary_sha256=hashlib.sha256(Path(b).read_bytes()).hexdigest(),source_manifest_sha256=hashlib.sha256((io/'ipad-ci-20261126-source.json').read_bytes()).hexdigest())
for lane,cmd in [('qemu',[q,'-cpu','max',b]),('native',[b])]:
 for case in ['continuous_peers_cancel_at_control_checkpoints_and_commit_the_exact_budget','sysinfo_and_live_cpu_statistics_keep_four_twelve_and_one_slot_cohorts']:
  start=time.monotonic()
  try:r=subprocess.run(cmd+[case,'--nocapture','--test-threads=1'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45);code=r.returncode;raw=r.stdout
  except subprocess.TimeoutExpired as e:code=124;raw=e.stdout or b''
  name='ipad-ci-v3-'+lane+'-'+case
  with gzip.open(io/(name+'.log.gz'),'wb') as z:z.write(raw)
  result=dict(lane=lane,case=case,code=code,seconds=time.monotonic()-start,build=receipt,tail=raw.decode(errors='replace')[-1900:])
  (io/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
