from pathlib import Path
import subprocess,tarfile,io,json,hashlib
root=Path('/Users/main/dev/trames'); out=root/'target/local-ci/io/ipad-ci-20261126-source';out.mkdir(exist_ok=False)
commits={}
for repo,dest in [(root,out),(root/'runtime',out/'runtime'),(root/'cli',out/'cli')]:
 commit=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();commits[str(dest.relative_to(out))]=commit
 data=subprocess.check_output(['git','-C',str(repo),'archive',commit]);dest.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(data)) as t:t.extractall(dest)
names=['process.rs','workers.rs','process_completion_tests.rs','process_lifecycle_dispatch.rs','process_vm.rs','process_dispatch_tests.rs','process_time_tests.rs','process_file_advice_tests.rs','process_published_proc_tests.rs','process_source_fault_tests.rs','process_uring_original_tests.rs','process_dormant_tests.rs','process_ioctl_tests.rs','process_lock_tests.rs']
import shutil
for n in names:shutil.copyfile(root/'runtime/crates/trames-session/src'/n,out/'runtime/crates/trames-session/src'/n)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()}
(out.parent/'ipad-ci-20261126-source.json').write_text(json.dumps(dict(commits=commits,files=manifest),indent=2,sort_keys=True)+'\n')
print('snapshot',commits,len(manifest),'files')
