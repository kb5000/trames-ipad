import subprocess,concurrent.futures,json,gzip,time
from pathlib import Path
io=Path('/mnt/trames-output');rows=[json.loads(x) for x in (io/'ipad-ci-v2-build.jsonl').read_text().splitlines() if x.startswith('{')];b=next(r['executable'] for r in reversed(rows) if r.get('executable') and r.get('target',{}).get('name')=='kernel-conformance');q='/home/main.guest/trames-ci/target/qemu-oracle/bin/qemu-aarch64'
def run(i):
 start=time.monotonic()
 try:r=subprocess.run([q,'-cpu','max',b,'continuous_peers_cancel_at_control_checkpoints_and_commit_the_exact_budget','--nocapture','--test-threads=1'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=12);code=r.returncode;raw=r.stdout
 except subprocess.TimeoutExpired as e:code=124;raw=e.stdout or b''
 with gzip.open(io/f'ipad-ci-budget-stress-{i}.log.gz','wb') as z:z.write(raw)
 result=dict(repetition=i,code=code,seconds=time.monotonic()-start,tail=raw.decode(errors='replace')[-750:]);print(json.dumps(result),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:results=list(executor.map(run,range(20)))
(io/'ipad-ci-budget-stress.json').write_text(json.dumps(results,indent=2)+'\n')
